//
//  SelectQIBusThemeViewController.swift

import UIKit

class SelectQIBusThemeViewController: UIViewController {

    //MARK: -
    //MARK: - Otulets
    
    @IBOutlet weak var btnRegularTheme: UIButton!
    @IBOutlet weak var btnSofUITheme: UIButton!
    @IBOutlet weak var btnSofUIDarkTheme: UIButton!
    
    @IBOutlet weak var lblPhoneCode: UILabel!
    @IBOutlet weak var lblYouWantTo: UILabel!
    @IBOutlet weak var lblTravel: UILabel!
    @IBOutlet weak var lblConnectUsing: UILabel!
    
    @IBOutlet weak var vwMobileNumber: UIView!

    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewWillAppear(_ animated: Bool) {
//        UIApplication.shared.statusBarView?.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        // Set fonts.
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblYouWantTo, size: fontSize(size: QIBUS_SIZE_XLARGE), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblConnectUsing, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblPhoneCode, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblTravel, size: fontSize(size: QIBUS_SIZE_XXXLARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnRegularTheme, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnSofUITheme, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnSofUIDarkTheme, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        
        // Set corner radious
        CornerRadiousWithBackground(view: btnRegularTheme, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        CornerRadiousWithBackground(view: btnSofUITheme, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        CornerRadiousWithBackground(view: btnSofUIDarkTheme, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        
    }
    
    //MARK: -
    //MARK: - UIButton Action Methods
        
    @IBAction func btnRegularTheme_Clicked(_ sender: Any) {
        backgroundColorChanged(color: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        let vc = ConnectViewController(nibName: "ConnectViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnSofUITheme_Clicked(_ sender: Any) {
        backgroundColorChanged(color: UIColor(hexString: PRIMARY_COLOR))
        let vc = SofUIConnectViewController(nibName: "SofUIConnectViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnSofUIDarkTheme_Clicked(_ sender: Any) {
        backgroundColorChanged(color: UIColor(hexString: PRIMARY_COLOR1))
        let vc = SoftUIDarkConnectViewController(nibName: "SoftUIDarkConnectViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
