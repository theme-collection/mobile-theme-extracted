//
//  SoftUIDarkCardViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 29/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkCardViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgAddress: UIImageView!
    @IBOutlet weak var imgOffer: UIImageView!
    @IBOutlet weak var imgCradHolder: UIImageView!
    @IBOutlet weak var imgCVV: UIImageView!
    @IBOutlet weak var imgYear: UIImageView!
    @IBOutlet weak var imgMonth: UIImageView!
    @IBOutlet weak var imgcard4: UIImageView!
    @IBOutlet weak var imgcard3: UIImageView!
    @IBOutlet weak var imgcard2: UIImageView!
    @IBOutlet weak var imgCard1: UIImageView!
    @IBOutlet weak var constraintBtnPaymenTop: NSLayoutConstraint!
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblPickupPoint: UILabel!
    @IBOutlet weak var lblPickupPointValue: UILabel!
    @IBOutlet weak var lblDroppingPoint: UILabel!
    @IBOutlet weak var lblDroppingPointValue: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var lblTotalAmountValue: UILabel!
    @IBOutlet weak var lblCardNo: UILabel!
    @IBOutlet weak var lblSelectMonth: UILabel!
    @IBOutlet weak var lblMonth: UILabel!
    @IBOutlet weak var lblSelectYear: UILabel!
    @IBOutlet weak var lblYear: UILabel!
    @IBOutlet weak var lblCardHolderName: UILabel!
    @IBOutlet weak var lblOfferCode: UILabel!
    @IBOutlet weak var lblCVV: UILabel!
    @IBOutlet weak var lblSuccess: UILabel!
    @IBOutlet weak var lblThankYou: UILabel!
    @IBOutlet weak var lblCountDown: UILabel!
    @IBOutlet weak var lblFromCity: UILabel!
    @IBOutlet weak var lblToCity: UILabel!
    @IBOutlet weak var lblLine: UILabel!
    
    @IBOutlet weak var txtCardNo1: UITextField!
    @IBOutlet weak var txtCardNo2: UITextField!
    @IBOutlet weak var txtCardNo3: UITextField!
    @IBOutlet weak var txtCardNo4: UITextField!
    @IBOutlet weak var txtCardHolderName: UITextField!
    @IBOutlet weak var txtCVV: UITextField!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwMain: UIView!
    @IBOutlet weak var vwAddress: UIView!
    @IBOutlet weak var vwOfferCode: UIView!
    @IBOutlet weak var vwSuccess: UIView!
    @IBOutlet weak var vwSuccessBackground: UIView!
    @IBOutlet weak var vwSelectMonthBackground: UIView!
    @IBOutlet weak var vwSelectYearBackground: UIView!
    @IBOutlet weak var vwAddressPoints: UIView!
    @IBOutlet weak var vwLocation: UIView!
    
    @IBOutlet weak var btnDetails: UIButton!
    @IBOutlet weak var btnBook: UIButton!
    @IBOutlet weak var btnArrow: UIButton!
    @IBOutlet weak var btnShowCVV: UIButton!
    @IBOutlet weak var btnFrom: UIButton!
    @IBOutlet weak var btnLocation: UIButton!
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    
    @IBOutlet weak var pickerMonthYear: UIPickerView!
    
    @IBOutlet weak var imgSuccess: UIImageView!
    
    //MARK: -
    //MARK: - Variables
    
    var count = 300
    var isFromAdd = Bool()
    var isFromMore = Bool()
    var pickerIdentifier = String()
    var strFromCity = String()
    var strToCity = String()
    let arrMonth = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]
    let arrYear = ["2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"]
    var isBackspacePressed = Bool()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }

    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        let resizableLogin = SWNinePatchImageFactory.createResizableNinePatchImageNamed("iqbus_Darkui_inner.9")
        
        imgCVV?.image = resizableLogin
        imgYear?.image = resizableLogin
        imgMonth?.image = resizableLogin
        imgcard4?.image = resizableLogin
        imgcard3?.image = resizableLogin
        imgcard2?.image = resizableLogin
        imgCard1?.image = resizableLogin
        imgOffer?.image = resizableLogin
        imgCradHolder?.image = resizableLogin
        
        pickerIdentifier = ""
        self.view.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        vwHeader.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        
//        CornerRadious(view: vwMain, cornerRadus: 10.0)
        CornerRadiousWithBackground(view: btnFrom, color: UIColor(hexString: PRIMARY_COLORDARK), cornerRadus: btnFrom.frame.height / 2)
//        CornerRadiousWithShadow(view: vwSelectMonthBackground, cornerRadus: 5.0)
//        CornerRadiousWithShadow(view: vwSelectYearBackground, cornerRadus: 5.0)
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
        setFontFamily(PRIMARY_FONT_BOLD, view: lblCountDown, size: fontSize(size: SIZE_MEDIUM), textColor: .white)
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPickupPoint, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblPickupPointValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblDroppingPoint, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblDroppingPointValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalAmount, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblTotalAmountValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblCardNo, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblSelectMonth, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblMonth, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblSelectYear, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblYear, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblCardHolderName, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblOfferCode, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblSuccess, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblThankYou, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblFromCity, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblToCity, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
//        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnBook, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnClose, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        btnClose.backgroundColor = UIColor(hexString: GREEN)
        
        btnLocation = setButtonTintColor(btnLocation, imageName: "icoLocation", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        imgSuccess = setImageTintColor(imgSuccess, tintColor: UIColor(hexString: GREEN))
        imgSuccess.contentMode = .scaleAspectFit
        
        btnArrow.setImage(UIImage(named: "icoRightArrow"), for: .normal)
        btnDetails.isSelected = false
        
        lblPickupPoint.text = ""
        lblPickupPointValue.text = ""
        lblDroppingPoint.text = ""
        lblDroppingPointValue.text = ""
        lblTotalAmount.text = ""
        lblTotalAmountValue.text = ""
//        vwAddressPoints.backgroundColor = .groupTableViewBackground
//        vwLocation.backgroundColor = .white
//        CornerRadiousWithShadow(view: vwLocation, cornerRadus: 5.0)
        
        btnShowCVV = setButtonTintColor(btnShowCVV, imageName: "icoVisibilityOff", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        txtCVV.isSecureTextEntry = true
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        pickerMonthYear.backgroundColor = .white
        
//        CornerRadiousWithBackground(view: btnBook, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
//        CornerRadiousWithShadow(view: vwSuccess, cornerRadus: 5.0)
//        CornerRadiousWithBorder(view: imgSuccess, color: UIColor(hexString: GREEN), cornerRadus: imgSuccess.frame.height / 2, borderWidth: 5.0)
        
        let resizableLogin1 = SWNinePatchImageFactory.createResizableNinePatchImageNamed("ios_Dark.9")
        btnBook.setBackgroundImage(resizableLogin1, for: UIControl.State.normal)
        
         let resizableLogin3 = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")
        self.imgAddress.image = resizableLogin3
        
        if isFromAdd {
            txtCardNo1.isUserInteractionEnabled = true
            txtCardNo2.isUserInteractionEnabled = true
            txtCardNo3.isUserInteractionEnabled = true
            txtCardNo4.isUserInteractionEnabled = true
            txtCardHolderName.isUserInteractionEnabled = true
            
            txtCardNo1.text = ""
            txtCardNo2.text = ""
            txtCardNo3.text = ""
            txtCardNo4.text = ""
            txtCardHolderName.text = ""
            lblLine.isHidden = true
        }
        else {
            txtCardNo1.isUserInteractionEnabled = false
            txtCardNo2.isUserInteractionEnabled = false
            txtCardNo3.isUserInteractionEnabled = false
            txtCardNo4.isUserInteractionEnabled = false
            txtCardHolderName.isUserInteractionEnabled = false
            
            txtCardNo1.text = "6253"
            txtCardNo2.text = "5686"
            txtCardNo3.text = "5623"
            txtCardNo4.text = "9563"
            txtCardHolderName.text = "John Smith"
            lblLine.isHidden = false
        }
        
        if isFromMore {
            vwOfferCode.isHidden = true
            vwAddress.isHidden = true
            lblHeading.text = "Add new card"
            btnBook.setTitle("Add Card", for: .normal)
            constraintBtnPaymenTop.priority = UILayoutPriority(rawValue: 600)
        }
        else {
            vwOfferCode.isHidden = false
            vwAddress.isHidden = false
            lblHeading.text = "Payment"
            btnBook.setTitle("Paynow", for: .normal)
            constraintBtnPaymenTop.priority = UILayoutPriority(rawValue: 800)
             _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
        }
        
        lblFromCity.text = strFromCity
        lblToCity.text = strToCity
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        vwSuccessBackground.addGestureRecognizer(tap)
        vwSuccess.isHidden = true
        vwSuccessBackground.isHidden = true
    }
    
    //MARK: -
    //MARK: - UITapGestureRecognizer
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        vwSuccess.isHidden = true
        vwSuccessBackground.isHidden = true
    }
    
    //MARK: -
    //MARK: - Picker View Delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerIdentifier == "month" {
            return arrMonth.count
        }
        else if pickerIdentifier == "year" {
            return arrYear.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerIdentifier == "month" {
            return arrMonth[row]
        }
        else if pickerIdentifier == "year" {
            return arrYear[row]
        }
        else {
            return nil
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerIdentifier == "month" {
           lblMonth.text = arrMonth[row]
        }
        else {
            lblYear.text = arrYear[row]
        }
    }
    
    //MARK: -
    //MARK: - UITextField Delegate
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var length = (textField.text?.count)!
        
        if let char = string.cString(using: String.Encoding.utf8) {
            let isBackSpace = strcmp(char, "\\b")
            if (isBackSpace == -92) {
                length = length - 1
                if length > 0 {
                    isBackspacePressed = false
                    return true
                }
                else {
                    isBackspacePressed = true
                    if textField.isEqual(txtCardNo1) {
                        textField.resignFirstResponder()
                    } else if textField.isEqual(txtCardNo2) {
                        txtCardNo1.becomeFirstResponder()
                    } else if textField.isEqual(txtCardNo3) {
                        txtCardNo2.becomeFirstResponder()
                    } else if textField.isEqual(txtCardNo4) {
                        txtCardNo3.becomeFirstResponder()
                    } else {
                    }
                    return false
                }
            }
        }
        
        if length > 3 {
            isBackspacePressed = false
            if textField.isEqual(txtCardNo1) {
                txtCardNo2.becomeFirstResponder()
            } else if textField.isEqual(txtCardNo2) {
                txtCardNo3.becomeFirstResponder()
            } else if textField.isEqual(txtCardNo3) {
                txtCardNo4.becomeFirstResponder()
            } else if textField.isEqual(txtCardNo4) {
                textField.resignFirstResponder()
            } else {
            }
            return false
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if isBackspacePressed == true {
            textField.text = ""
            isBackspacePressed = false
        }
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnDetails_Clicked(_ sender: Any) {
        btnDetails.isSelected = !btnDetails.isSelected
        /*if btnDetails.isSelected {
            btnArrow.setImage(UIImage(named: "icoDownArrowAngle"), for: .normal)
            
//            vwAddressPoints.backgroundColor = .white
//            vwLocation.backgroundColor = .clear
//            CornerRadiousWithShadow(view: vwAddress, cornerRadus: 5.0)
//            RemoveCornerRadiousWithShadow(view: vwLocation)
            
            lblPickupPoint.text = "Pickup point"
            lblPickupPointValue.text = "Chandkheda"
            lblDroppingPoint.text = "Dropping point"
            lblDroppingPointValue.text = "Chandkheda"
            lblTotalAmount.text = "Total Amount"
            lblTotalAmountValue.text = "$ 40"
            
            lblLine.isHidden = false
        }
        else {
            btnArrow.setImage(UIImage(named: "icoRightArrow"), for: .normal)
            
//            vwAddressPoints.backgroundColor = .groupTableViewBackground
//            vwLocation.backgroundColor = .white
//            RemoveCornerRadiousWithShadow(view: vwAddress)
//            CornerRadiousWithShadow(view: vwLocation, cornerRadus: 5.0)
            
            lblPickupPoint.text = ""
            lblPickupPointValue.text = ""
            lblDroppingPoint.text = ""
            lblDroppingPointValue.text = ""
            lblTotalAmount.text = ""
            lblTotalAmountValue.text = ""
            lblLine.isHidden = true
        }*/
    }
    
    @IBAction func btnSelectMonth_Clicked(_ sender: Any) {
        pickerIdentifier = "month"
        pickerMonthYear.reloadAllComponents()
        pickerMonthYear.isHidden = false
        btnDone.isHidden = false
    }
    
    @IBAction func btnSelectYear_Clicked(_ sender: Any) {
        pickerIdentifier = "year"
        pickerMonthYear.reloadAllComponents()
        pickerMonthYear.isHidden = false
        btnDone.isHidden = false
    }
    
    @IBAction func btnBook_Clicked(_ sender: Any) {
        view.endEditing(true)
        pickerMonthYear.isHidden = true
        btnDone.isHidden = true
        
        if isFromMore {
            view.makeToast("Card Added")
        }
        else {
            vwSuccess.isHidden = false
            vwSuccessBackground.isHidden = false
        }
    }
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnShowCVV_Clicked(_ sender: Any) {
        btnShowCVV.isSelected = !btnShowCVV.isSelected
        if btnShowCVV.isSelected {
            btnShowCVV = setButtonTintColor(btnShowCVV, imageName: "icoVisibility", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
            txtCVV.isSecureTextEntry = false
        }
        else {
            btnShowCVV = setButtonTintColor(btnShowCVV, imageName: "icoVisibilityOff", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
            txtCVV.isSecureTextEntry = true
        }
    }
    
    @IBAction func btnClose_Clicked(_ sender: Any) {
        vwSuccess.isHidden = true
        vwSuccessBackground.isHidden = true
        self.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: {})

    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        pickerMonthYear.isHidden = true
        btnDone.isHidden = true
    }
    
    //MARK: -
    //MARK: - Other Methods
    
    @objc func update() {
        if(count > 0) {
            let minutes = String(count / 60)
            let seconds = String(count % 60)
            lblCountDown.text = minutes + ":" + seconds
            count = count - 1
        }
        else {
            dismiss(animated: true, completion: nil)
        }
    }
}
