//
//  SoftUIDarkMyBookingViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 26/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkMyBookingViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var cvBooking: UICollectionView!
    
    @IBOutlet weak var segmentBooking: UISegmentedControl!
    
    //MARK: -
    //MARK: - Variables
    
    var index = Int()
    var selectedIndex = Int()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        index = -1
        selectedIndex = 0
        
        segmentBooking.tintColor = BackgroundSettings.sharedService.backgroundColor        
        SegmentApprience(segment: segmentBooking)
    }

    //MARK: -
    //MARK: - UISegment Click
    
    @IBAction func segmentBooking_Clicked(_ sender: Any) {
        if segmentBooking.selectedSegmentIndex == 0 {
            selectedIndex = 0
            index = -1
            cvBooking.reloadData()
        }
        else {
            selectedIndex = 1
            index = -1
            cvBooking.reloadData()
        }
    }
    
    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if selectedIndex == 0 {
            return 3
        }
        else {
            return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cvBooking.register(UINib(nibName: "SoftUIDarkBookingCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        let cell = cvBooking.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SoftUIDarkBookingCollectionCell
        
        if selectedIndex == 0 {
            cell.lblConfirmed.text = "Confirmed"
            cell.lblConfirmed.textColor = UIColor(hexString: GREEN)
            cell.imgConfirmed.backgroundColor = .white
            cell.imgCompleated.image = UIImage(named: "icoCompleted")
            cell.imgConfirmed.image = UIImage(named: "icoChecked")
            cell.imgConfirmed = setImageTintColor(cell.imgConfirmed, tintColor: UIColor(hexString: GREEN))
        }
        else {
            cell.lblConfirmed.text = "Cancelled"
            cell.lblConfirmed.textColor = .red
            cell.imgConfirmed.backgroundColor = .red
            cell.imgCompleated.image = UIImage(named: "icoCanceled")
            cell.imgConfirmed.image = UIImage(named: "icoClose")
            cell.imgConfirmed = setImageTintColor(cell.imgConfirmed, tintColor: .white)
        }
        
        if index == indexPath.item {
            cell.lblConfirmed.isHidden = true
            cell.imgConfirmed.isHidden = true
            cell.vwTime.isHidden = false
            cell.vwSeatNo.isHidden = false
            cell.btnArrow.setImage(UIImage(named: "icoUpArrow"), for: .normal)
        }
        else {
            cell.lblConfirmed.isHidden = false
            cell.imgConfirmed.isHidden = false
            cell.vwTime.isHidden = true
            cell.vwSeatNo.isHidden = true
            cell.btnArrow.setImage(UIImage(named: "icoDownArrowAngle"), for: .normal)
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        if IPAD {
//            if index == indexPath.item {
//                return CGSize(width: UIScreen.main.bounds.size.width-16, height: 400)
//            }
//            else {
//                return CGSize(width: UIScreen.main.bounds.size.width-16, height: 120)
//            }
//        }
//        else {
            if index == indexPath.item {
                return CGSize(width: UIScreen.main.bounds.size.width, height: 350)
            }
            else {
                return CGSize(width: UIScreen.main.bounds.size.width, height: 140)
            }
//        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if index == indexPath.item {
            index = -1
        }
        else {
            index = indexPath.item
        }
        cvBooking.reloadData()
    }
}
