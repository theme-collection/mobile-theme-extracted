//
//  SoftUIDarkOffersViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 26/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkOffersViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    
    @IBOutlet weak var lblHeading: UILabel!
    
    @IBOutlet weak var cvOffers: UICollectionView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrOffer = ["icoSale1", "icoSale2", "icoSale1", "icoSale2", "icoSale1", "icoSale2"]
    let arrColor = [UIColor.yellow, UIColor.blue, UIColor.green, UIColor.blue, UIColor.yellow, UIColor.green]
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        vwHeader.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        
        CornerRadious(view: cvOffers, cornerRadus: 10.0)
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
    }
    
    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrOffer.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cvOffers.register(UINib(nibName: "OffersCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        
        let cell = cvOffers.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! OffersCollectionCell
        
//        CornerRadiousWithShadow(view: cell, cornerRadus: 5.0)
//        cell.imgOffer.image = UIImage(named: arrOffer[indexPath.item])
//        cell.imgOffer.backgroundColor = arrColor[indexPath.item]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        view.makeToast("Copied")
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        if IPAD {
//            return CGSize(width: UIScreen.main.bounds.size.width-32, height: 180)
//        }
//        else {
//            return CGSize(width: UIScreen.main.bounds.size.width-16, height: 150)
//        }
         return CGSize(width: UIScreen.main.bounds.size.width, height: 130)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        willDisplay cell: UICollectionViewCell,
                        forItemAt indexPath: IndexPath) {
        cell.contentView.alpha = 0.3
        
        cell.layer.transform = CATransform3DMakeScale(0.5, 0.5, 0.5)
        
        // Simple Animation
        UIView.animate(withDuration: 0.5) {
            cell.contentView.alpha = 1
            cell.layer.transform = CATransform3DScale(CATransform3DIdentity, 1, 1, 1)
        }
    }

    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
