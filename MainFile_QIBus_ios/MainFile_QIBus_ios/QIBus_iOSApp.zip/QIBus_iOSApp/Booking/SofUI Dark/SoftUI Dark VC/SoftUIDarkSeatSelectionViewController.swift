//
//  SoftUIDarkSeatSelectionViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 25/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit
import Toast_Swift

class SoftUIDarkSeatSelectionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imginner2: UIImageView!
    @IBOutlet weak var imgInner1: UIImageView!
    @IBOutlet weak var imgContact: UIImageView!
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    @IBOutlet weak var constraintPassengerInfoTblHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintBookNowHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintSegmentHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintTblSeatSelectionHeight: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwTemp: UIView!
    @IBOutlet var vwSeatSelection: UIView!
    @IBOutlet var vwPickupPoint: UIView!
    @IBOutlet var vwPassengerInfo: UIView!
    @IBOutlet weak var vwContactInfo: UIView!
    @IBOutlet weak var vwBookNow: UIView!
    @IBOutlet weak var vwHold: UIView!
    
    @IBOutlet weak var btnSelectSeatVerified: UIButton!
    @IBOutlet weak var btnSelectPointVerified: UIButton!
    @IBOutlet weak var btnBookVerified: UIButton!
    @IBOutlet weak var btnBookNow: UIButton!
    @IBOutlet weak var btnBook: UIButton!
    @IBOutlet weak var btnAvailable: UIButton!
    @IBOutlet weak var btnBooked: UIButton!
    @IBOutlet weak var btnSelected: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnLadies: UIButton!
    @IBOutlet weak var btnHold1: UIButton!
    @IBOutlet weak var btnHold2: UIButton!
    @IBOutlet weak var btnDestination: UIButton!
    
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblHeadingBusName: UILabel!
    @IBOutlet weak var lblHeadingDate: UILabel!
    @IBOutlet weak var lblAvailable: UILabel!
    @IBOutlet weak var lblBooked: UILabel!
    @IBOutlet weak var lblSelected: UILabel!
    @IBOutlet weak var lblContactInfo: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblLadies: UILabel!
    @IBOutlet weak var lblTicketPrice: UILabel!
    @IBOutlet weak var lblTax: UILabel!
    @IBOutlet weak var lblTaxValue: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhoneNo: UITextField!
    
    @IBOutlet weak var SegmentUpperLower: UISegmentedControl!
    @IBOutlet weak var segmentPickup: UISegmentedControl!
    
    @IBOutlet weak var pickerGender: UIPickerView!
    
    @IBOutlet weak var tblSeatSelection: UITableView!
    @IBOutlet weak var tblPickup: UITableView!
    @IBOutlet weak var tblPassengerList: UITableView!
    
    //MARK: -
    //MARK: - Variables
    
    var strBus = String()
    var dicSleeperSeat = NSDictionary()
    var dicVolvoSeat = NSDictionary()
    var arrSelectedVolvo = NSMutableArray()
    var arrSelectedSleeper = NSMutableArray()
    
    var arrVolvoBooked:NSArray = [06, 09, 12, 15, 22, 25, 28, 31]
    var arrSleeperBooked:NSArray = [04, 08, 13, 17]
    var arrVolvoladies:NSArray = [02, 05, 08, 11, 18, 25]
    var arrSleeperladies:NSArray = [09, 18]
    
    let arrGender = ["Male", "Female", "Other"]
    let arrSelectedGender = NSMutableArray()
    
    var indexSegment1 = Int()
    var indexSegment2 = Int()
    var tax = Int()
    var tag = Int()
    var strGender = String()
    var strFromCity = String()
    var strToCity = String()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }

    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        lblHeadingBusName.text = "Select Seat"
        indexSegment1 = -1
        indexSegment2 = -1
        tax = 5
        
        self.view.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        vwHeader.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        btnBookNow.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        self.btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        pickerGender.backgroundColor = .white
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
//        btnBookNow.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeadingBusName, size: fontSize(size: SIZE_LARGE), textColor: .white)
        setFontFamily(PRIMARY_FONT, view: lblHeadingDate, size: fontSize(size: SIZE_SMALL), textColor: .white)
        setFontFamily(PRIMARY_FONT, view: lblAvailable, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: LIGHT_GRAY))
        setFontFamily(PRIMARY_FONT, view: lblBooked, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: DARK_GRAY))
        setFontFamily(PRIMARY_FONT, view: lblSelected, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblLadies, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblAmount, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblContactInfo, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblEmail, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblPhone, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTicketPrice, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTax, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTaxValue, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotal, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalAmount, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnBookNow, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
//        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnBook, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        
        setFontFamily(PRIMARY_FONT, view: txtEmail, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: txtPhoneNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        btnDestination = setButtonTintColor(btnDestination, imageName: "icoLocation", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        
//        Shadow(view: vwBookNow)
//        CornerRadiousWithBackground(view: btnBook, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
//        CornerRadiousWithShadow(view: vwContactInfo, cornerRadus: 5.0)
//        CornerRadiousWithBackground(view: btnSelectSeatVerified, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: btnSelectSeatVerified.frame.height / 2)
//        CornerRadiousWithBackground(view: btnSelectPointVerified, color: UIColor(hexString: LIGHT_GRAY), cornerRadus: btnSelectPointVerified.frame.height / 2)
//        CornerRadiousWithBackground(view: btnBookVerified, color: UIColor(hexString: LIGHT_GRAY), cornerRadus: btnBookVerified.frame.height / 2)
        CornerRadiousWithBackground(view: btnHold1, color: UIColor(hexString: PRIMARY_COLORDARK), cornerRadus: btnHold1.frame.height / 2)
        CornerRadiousWithBackground(view: btnHold2, color: UIColor(hexString: PRIMARY_COLORDARK), cornerRadus: btnHold2.frame.height / 2)
        CornerRadious(view: vwTemp, cornerRadus: 10.0)
        
        SegmentUpperLower.tintColor = BackgroundSettings.sharedService.backgroundColor
        segmentPickup.tintColor = BackgroundSettings.sharedService.backgroundColor
        
        SegmentApprience(segment: SegmentUpperLower)
        SegmentApprience(segment: segmentPickup)
        
        vwTemp.addSubview(vwSeatSelection)
        vwSeatSelection.frame = vwTemp.bounds
        vwSeatSelection.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        tblSeatSelection.tableFooterView = UIView(frame: .zero)
        tblPickup.tableFooterView = UIView(frame: .zero)
        
        if strBus == "Seater" {
            btnAvailable.backgroundColor = UIColor(hexString: LIGHT_GRAY)
            btnAvailable.roundCorners([.topRight, .topLeft], radius: 5.0)
            
            btnBooked.backgroundColor = UIColor(hexString: DARK_GRAY)
            btnBooked.roundCorners([.topRight, .topLeft], radius: 5.0)
            
            btnSelected.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
            btnSelected.roundCorners([.topRight, .topLeft], radius: 5.0)
            
            btnLadies.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
            btnLadies.roundCorners([.topRight, .topLeft], radius: 5.0)
            
            constraintSegmentHeight.constant = 0
            SegmentUpperLower.layoutIfNeeded()
            SegmentUpperLower.isHidden = true
        }
        else {
            CornerRadiousWithBackground(view: btnAvailable, color: UIColor(hexString: LIGHT_GRAY), cornerRadus: 5.0)
            CornerRadiousWithBackground(view: btnBooked, color: UIColor(hexString: DARK_GRAY), cornerRadus: 5.0)
            CornerRadiousWithBackground(view: btnSelected, color: UIColor(hexString: PRIMARY_COLORDARK), cornerRadus: 5.0)
            CornerRadiousWithBackground(view: btnLadies, color: UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5), cornerRadus: 5.0)
            
            if IPAD {
                constraintSegmentHeight.constant = 50
            }
            else {
                constraintSegmentHeight.constant = 40
            }
            SegmentUpperLower.isHidden = false
        }
        
        dicSleeperSeat = ["row1" : [01, 02, 03],
                   "row2" : [04, 05, 06],
                   "row3" : [07, 08, 09],
                   "row4" : [10, 11, 12],
                   "row5" : [13, 14, 15],
                   "row6" : [16, 17, 18],
                   "row7" : [19, 20, 21]
        ]
        
        dicVolvoSeat = ["row1" : [01, 02, 03, 04],
                          "row2" : [05, 06, 07, 08],
                          "row3" : [09, 10, 11, 12],
                          "row4" : [13, 14, 15, 16],
                          "row5" : [17, 18, 19, 20],
                          "row6" : [21, 22, 23, 24],
                          "row7" : [25, 26, 27 ,28],
                          "row8" : [29, 30, 31, 32]
        ]
        
        self.lblAmount.text = "$ 0"
        lblTaxValue.text = "$ \(tax)"
        Book()
        let resizableLogin = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")
        imgContact.image = resizableLogin
        
        let resizableLogin1 = SWNinePatchImageFactory.createResizableNinePatchImageNamed("iqbus_Darkui_inner.9")
        imgInner1?.image = resizableLogin1
        imginner2?.image = resizableLogin1
        
        
               let resizableLogin2 = SWNinePatchImageFactory.createResizableNinePatchImageNamed("ios_Dark.9")
               btnBook.setBackgroundImage(resizableLogin2, for: UIControl.State.normal)
        vwHold.roundCorners([.topRight, .bottomRight], radius: 10.0)
    }
    
    //MARK: -
    //MARK: - Picker View Delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrGender.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrGender[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        strGender = arrGender[row]
    }
    
    //MARK: -
    //MARK: - UITableView DataSource & Delegate
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblSeatSelection {
            if strBus == "Seater" {
                return dicVolvoSeat.allKeys.count
            }
            else {
                return dicSleeperSeat.allKeys.count
            }
        }
        else if tableView == tblPickup {
            if segmentPickup.selectedSegmentIndex == 0 {
                return 2
            }
            else {
                return 2
            }
        }
        else {
            if strBus == "Seater" {
                return arrSelectedVolvo.count
            }
            else {
                return arrSelectedSleeper.count
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tblSeatSelection {
            if IPAD {
                if strBus == "Seater" {
                    constraintTblSeatSelectionHeight.constant = CGFloat(dicVolvoSeat.allKeys.count * 100)
                    return 100
                }
                else {
                    constraintTblSeatSelectionHeight.constant = CGFloat(dicSleeperSeat.allKeys.count * 150)
                    return 150
                }
            }
            else {
                if strBus == "Seater" {
                    constraintTblSeatSelectionHeight.constant = CGFloat(dicVolvoSeat.allKeys.count * 75)
                    return 75
                }
                else {
                    constraintTblSeatSelectionHeight.constant = CGFloat(dicSleeperSeat.allKeys.count * 100)
                    return 100
                }
            }
        }
        else if tableView == tblPickup {
                return 120
        }
        else {
            if IPAD {
                if strBus == "Seater" {
                    constraintPassengerInfoTblHeight.constant = CGFloat(200 * arrSelectedVolvo.count)
                }
                else {
                    constraintPassengerInfoTblHeight.constant = CGFloat(200 * arrSelectedSleeper.count)
                }
                return 200
            }
            else {
                if strBus == "Seater" {
                    constraintPassengerInfoTblHeight.constant = CGFloat(200 * arrSelectedVolvo.count)
                }
                else {
                    constraintPassengerInfoTblHeight.constant = CGFloat(200 * arrSelectedSleeper.count)
                }
                return 200
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tblSeatSelection {
            if strBus == "Seater" {
                tblSeatSelection.register(UINib(nibName: "SoftUIDarkVolvoSeatSelectionableViewCell", bundle: nil), forCellReuseIdentifier: "Cell")
                
                let cell = tblSeatSelection.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SoftUIDarkVolvoSeatSelectionableViewCell
                
                let temp:NSArray = dicVolvoSeat.object(forKey: "row\(indexPath.row + 1)") as! NSArray
                
                cell.btnSeat1.tag = temp.object(at: 0) as! Int
                cell.btnSeat1.addTarget(self, action: #selector(onClickVolvoSeat1(_:)), for: UIControl.Event.touchUpInside)
                
                cell.btnSeat2.tag = temp.object(at: 1) as! Int
                cell.btnSeat2.addTarget(self, action: #selector(onClickVolvoSeat2(_:)), for: UIControl.Event.touchUpInside)
                
                cell.btnSeat3.tag = temp.object(at: 2) as! Int
                cell.btnSeat3.addTarget(self, action: #selector(onClickVolvoSeat3(_:)), for: UIControl.Event.touchUpInside)
                
                cell.btnSeat4.tag = temp.object(at: 3) as! Int
                cell.btnSeat4.addTarget(self, action: #selector(onClickVolvoSeat4(_:)), for: UIControl.Event.touchUpInside)
                
                if arrSelectedVolvo .contains(cell.btnSeat1.tag){
                    cell.btnSeat1.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[0] as! Int > 9 {
                        cell.lblSeat1.text = "L\(temp[0])"
                    }
                    else {
                        cell.lblSeat1.text = "L0\(temp[0])"
                    }
                } else {
                    if arrVolvoBooked.contains(cell.btnSeat1.tag) {
                        cell.btnSeat1.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat1.text = ""
                    }
                    else if arrVolvoladies.contains(cell.btnSeat1.tag) {
                        cell.btnSeat1.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat1.text = ""
                    }
                    else {
                        cell.btnSeat1.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat1.text = ""
                    }
                }
                
                if arrSelectedVolvo .contains(cell.btnSeat2.tag){
                    cell.btnSeat2.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[1] as! Int > 9 {
                        cell.lblSeat2.text = "L\(temp[1])"
                    }
                    else
                    {
                        cell.lblSeat2.text = "L0\(temp[1])"
                    }
                } else {
                    if arrVolvoBooked.contains(cell.btnSeat2.tag){
                        cell.btnSeat2.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat2.text = ""
                    }
                    else if arrVolvoladies.contains(cell.btnSeat2.tag) {
                        cell.btnSeat2.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat2.text = ""
                    }
                    else {
                        cell.btnSeat2.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat2.text = ""
                    }
                }
                
                if arrSelectedVolvo .contains(cell.btnSeat3.tag){
                    cell.btnSeat3.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[2] as! Int > 9 {
                        cell.lblSeat3.text = "L\(temp[2])"
                    }
                    else {
                        cell.lblSeat3.text = "L0\(temp[2])"
                    }
                } else {
                    if arrVolvoBooked.contains(cell.btnSeat3.tag){
                        cell.btnSeat3.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat3.text = ""
                    }
                    else if arrVolvoladies.contains(cell.btnSeat3.tag) {
                        cell.btnSeat3.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat3.text = ""
                    }
                    else {
                        cell.btnSeat3.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat3.text = ""
                    }
                }
                
                if arrSelectedVolvo .contains(cell.btnSeat4.tag){
                    cell.btnSeat4.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[3] as! Int > 9 {
                        cell.lblSeat4.text = "L\(temp[3])"
                    }
                    else {
                        cell.lblSeat4.text = "L0\(temp[3])"
                    }
                } else {
                    if arrVolvoBooked.contains(cell.btnSeat4.tag){
                        cell.btnSeat4.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat4.text = ""
                    }
                    else if arrVolvoladies.contains(cell.btnSeat4.tag) {
                        cell.btnSeat4.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat4.text = ""
                    }
                    else {
                        cell.btnSeat4.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat4.text = ""
                    }
                }
                
                cell.selectionStyle = .none
                return cell
            }
            else {
                tblSeatSelection.register(UINib(nibName: "SoftUIDarkSeatSelectionTableCell", bundle: nil), forCellReuseIdentifier: "Cell")
                
                let cell = tblSeatSelection.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SoftUIDarkSeatSelectionTableCell
                
                let temp:NSArray = dicSleeperSeat.object(forKey: "row\(indexPath.row + 1)") as! NSArray
                
                cell.btnSeat1.tag = temp.object(at: 0) as! Int
                cell.btnSeat1.addTarget(self, action: #selector(onClickSleeperSeat1(_:)), for: UIControl.Event.touchUpInside)
                
                cell.btnSeat2.tag = temp.object(at: 1) as! Int
                cell.btnSeat2.addTarget(self, action: #selector(onClickSleeperSeat2(_:)), for: UIControl.Event.touchUpInside)
                
                cell.btnSeat3.tag = temp.object(at: 2) as! Int
                cell.btnSeat3.addTarget(self, action: #selector(onClickSleeperSeat3(_:)), for: UIControl.Event.touchUpInside)
                
                if arrSelectedSleeper .contains(cell.btnSeat1.tag){
                    cell.btnSeat1.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[0] as! Int > 9 {
                        cell.lblSeat1.text = "L\(temp[0])"
                    }
                    else {
                        cell.lblSeat1.text = "L0\(temp[0])"
                    }
                } else {
                    if arrSleeperBooked.contains(cell.btnSeat1.tag){
                        cell.btnSeat1.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat1.text = ""
                    }
                    else if arrSleeperladies.contains(cell.btnSeat1.tag) {
                        cell.btnSeat1.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat1.text = ""
                    }
                    else {
                        cell.btnSeat1.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat1.text = ""
                    }
                }
                
                if arrSelectedSleeper .contains(cell.btnSeat2.tag){
                    cell.btnSeat2.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[1] as! Int > 9 {
                        cell.lblSeat2.text = "L\(temp[1])"
                    }
                    else {
                        cell.lblSeat2.text = "L0\(temp[1])"
                    }
                } else {
                    if arrSleeperBooked.contains(cell.btnSeat2.tag){
                        cell.btnSeat2.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat2.text = ""
                    }
                    else if arrSleeperladies.contains(cell.btnSeat2.tag) {
                        cell.btnSeat2.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat2.text = ""
                    }
                    else {
                        cell.btnSeat2.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat2.text = ""
                    }
                }
                
                if arrSelectedSleeper .contains(cell.btnSeat3.tag){
                    cell.btnSeat3.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
                    if temp[2] as! Int > 9 {
                        cell.lblSeat3.text = "L\(temp[2])"
                    }
                    else {
                        cell.lblSeat3.text = "L0\(temp[2])"
                    }
                } else {
                    if arrSleeperBooked.contains(cell.btnSeat3.tag){
                        cell.btnSeat3.backgroundColor = UIColor(hexString: DARK_GRAY)
                        cell.lblSeat3.text = ""
                    }
                    else if arrSleeperladies.contains(cell.btnSeat3.tag) {
                        cell.btnSeat3.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK, alpha: 0.5)
                        cell.lblSeat3.text = ""
                    }
                    else {
                        cell.btnSeat3.backgroundColor = UIColor(hexString: LIGHT_GRAY)
                        cell.lblSeat3.text = ""
                    }
                }
                
                cell.selectionStyle = .none
                return cell
            }
        }
        else if tableView == tblPickup {
            tblPickup.register(UINib(nibName: "SoftUIDarkPickUpTableCell", bundle: nil), forCellReuseIdentifier: "Cell")
            
            let cell = tblPickup.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SoftUIDarkPickUpTableCell
            
            if segmentPickup.selectedSegmentIndex == 0 {
                cell.lblPickup.text = "Pickup \(indexPath.row + 1)"
                
                if indexSegment1 == indexPath.row {
                    cell.vwPickup.layer.borderWidth = 1
                    cell.vwPickup.layer.borderColor = UIColor(hexString: PRIMARY_COLORDARK).cgColor
                }
                else {
                    cell.vwPickup.layer.borderWidth = 0
                    cell.vwPickup.layer.borderColor = UIColor.clear.cgColor
                }
            }
            else {
                cell.lblPickup.text = "Dropping \(indexPath.row + 1)"
                
                if indexSegment2 == indexPath.row {
                    cell.vwPickup.layer.borderWidth = 1
                    cell.vwPickup.layer.borderColor = UIColor(hexString: PRIMARY_COLORDARK).cgColor
                }
                else {
                    cell.vwPickup.layer.borderWidth = 0
                    cell.vwPickup.layer.borderColor = UIColor.clear.cgColor
                }
            }
            cell.selectionStyle = .none
            return cell
        }
        else {
            tblPassengerList.register(UINib(nibName: "SoftUIDarkPassengerDetailsTableCell", bundle: nil), forCellReuseIdentifier: "Cell")
            
            let cell = tblPassengerList.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SoftUIDarkPassengerDetailsTableCell
            
            if strBus == "Seater" {
                if arrSelectedVolvo[indexPath.row] as! Int > 9 {
                    cell.lblSeatNo.text = "Seat L\(arrSelectedVolvo[indexPath.row])"
                }
                else {
                    cell.lblSeatNo.text = "Seat L0\(arrSelectedVolvo[indexPath.row])"
                }
            }
            else {
                if arrSelectedSleeper[indexPath.row] as! Int > 9 {
                    cell.lblSeatNo.text = "Seat L\(arrSelectedSleeper[indexPath.row])"
                }
                else {
                    cell.lblSeatNo.text = "Seat L0\(arrSelectedSleeper[indexPath.row])"
                }
            }
            
            if arrSelectedGender.count > 0 {
                cell.lblGender.text = arrSelectedGender[indexPath.row] as? String
            }
            else {
                cell.lblGender.text = "Male"
            }
            
            cell.btnGender.tag = indexPath.row
            cell.btnGender.addTarget(self, action: #selector(onClickGender(_:)), for: UIControl.Event.touchUpInside)
            
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tblPickup {
            if segmentPickup.selectedSegmentIndex == 0 {
                indexSegment1 = indexPath.row
                segmentPickup.selectedSegmentIndex = 1
            }
            else {
                lblHeadingBusName.text = "Add Passenger"
                
                indexSegment2 = indexPath.row
                btnSelectSeatVerified.backgroundColor = .clear
                btnSelectPointVerified.backgroundColor = .clear
                btnBookVerified.backgroundColor = BackgroundSettings.sharedService.backgroundColor
                btnSelectSeatVerified = setButtonTintColor(btnSelectSeatVerified, imageName: "icoChecked", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
                btnSelectPointVerified = setButtonTintColor(btnSelectPointVerified, imageName: "icoChecked", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
                
                vwPickupPoint.removeFromSuperview()
                vwTemp.addSubview(vwPassengerInfo)
                vwPassengerInfo.frame = vwTemp.bounds
                vwPassengerInfo.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            }
        }
        tblPickup.reloadData()
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        if vwSeatSelection.isDescendant(of: vwTemp) {
            dismiss(animated: true, completion: nil)
        }
        else if vwPickupPoint.isDescendant(of: vwTemp) {
            lblHeadingBusName.text = "Select Seat"
            vwPickupPoint.removeFromSuperview()
            vwTemp.addSubview(vwSeatSelection)
            vwSeatSelection.frame = vwTemp.bounds
            vwSeatSelection.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        }
        else if vwPassengerInfo.isDescendant(of: vwTemp) {
            lblHeadingBusName.text = "Pickup - Dropping Point"
            vwPassengerInfo.removeFromSuperview()
            vwTemp.addSubview(vwPickupPoint)
            vwPickupPoint.frame = vwTemp.bounds
            vwPickupPoint.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        }
    }
    
    @IBAction func btnBookNow_Clicked(_ sender: Any) {
        if strBus == "Seater" {
            for _ in 0..<arrSelectedVolvo.count {
                arrSelectedGender.add("Male")
            }
        }
        else {
            for _ in 0..<arrSelectedSleeper.count {
                arrSelectedGender.add("Male")
            }
        }
        tblPassengerList.reloadData()
        
        lblHeadingBusName.text = "Pickup - Dropping Point"
        btnSelectSeatVerified.backgroundColor = .clear
        btnSelectPointVerified.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        btnBookVerified.backgroundColor = UIColor(hexString: LIGHT_GRAY)
        btnSelectSeatVerified = setButtonTintColor(btnSelectSeatVerified, imageName: "icoChecked", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        
        vwSeatSelection.removeFromSuperview()
        vwTemp.addSubview(vwPickupPoint)
        vwPickupPoint.frame = vwTemp.bounds
        vwPickupPoint.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    }
    
    @IBAction func btnBookClicked(_ sender: Any) {
        view.endEditing(true)
        pickerGender.isHidden = true
        btnDone.isHidden = true
        
        let vc = SoftUIDarkPaymentViewController(nibName: "SoftUIDarkPaymentViewController", bundle: nil)
        vc.strFromCity = strFromCity
        vc.strToCity = strToCity
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        arrSelectedGender.replaceObject(at: tag, with: strGender)
        pickerGender.isHidden = true
        btnDone.isHidden = true
        tblPassengerList.reloadData()
    }
    
    @IBAction func btnHold1_Clicked(_ sender: Any) {
        self.view.makeToast("Hold")
    }
    
    @IBAction func btnHold2_Clicked(_ sender: Any) {
        self.view.makeToast("Hold")
    }
    
    @IBAction func btnDestination_Clicked(_ sender: Any) {
        self.view.makeToast("Destination")
    }
    
    //MARK: -
    //MARK: - Segment Click Event
    
    @IBAction func segmentPicker_Clicked(_ sender: UISegmentedControl) {
        tblPickup.reloadData()
    }
    
    //MARK: -
    //MARK: - OnClick Cell Button
    
    @objc func onClickVolvoSeat1(_ sender: UIButton?) {
        VolvoSeatBook(sender: sender)
    }
    
    @objc func onClickVolvoSeat2(_ sender: UIButton?) {
        VolvoSeatBook(sender: sender)
    }
    
    @objc func onClickVolvoSeat3(_ sender: UIButton?) {
        VolvoSeatBook(sender: sender)
    }
    
    @objc func onClickVolvoSeat4(_ sender: UIButton?) {
        VolvoSeatBook(sender: sender)
    }
    
    @objc func onClickSleeperSeat1(_ sender: UIButton?) {
        SleeperSeatBook(sender: sender)
    }
    
    @objc func onClickSleeperSeat2(_ sender: UIButton?) {
        SleeperSeatBook(sender: sender)
    }
    
    @objc func onClickSleeperSeat3(_ sender: UIButton?) {
        SleeperSeatBook(sender: sender)
    }
    
    @objc func onClickGender(_ sender: UIButton?) {
        view.endEditing(true)
        tag = sender!.tag
        pickerGender.isHidden = false
        btnDone.isHidden = false
    }

    //MARK: -
    //MARK: - Other Methods
    
    func Book() {
        if arrSelectedVolvo.count > 0 {
                constraintBookNowHeight.constant = 40
                lblTicketPrice.text = "Ticket Price:"
                lblAmount.text = ""
                lblTax.text = "Tax:"
                lblTaxValue.text = "$ \(tax)"
                lblTotal.text = "Total:"
                lblTotalAmount.text = ""
                vwBookNow.isHidden = false
        }
        else if arrSelectedSleeper.count > 0 {
                constraintBookNowHeight.constant = 40
                lblTicketPrice.text = "Ticket Price:"
                lblAmount.text = ""
                lblTax.text = "Tax:"
                lblTaxValue.text = "$ \(tax)"
                lblTotal.text = "Total:"
                lblTotalAmount.text = ""
                vwBookNow.isHidden = false
        }
        else {
            constraintBookNowHeight.constant = 0
            lblTicketPrice.text = ""
            lblAmount.text = ""
            lblTax.text = ""
            lblTaxValue.text = ""
            lblTotal.text = ""
            lblTotalAmount.text = ""
            vwBookNow.isHidden = true
        }
    }
    
    func VolvoSeatBook(sender: UIButton?) {
        if sender!.isSelected {
            sender?.isSelected = false
            arrSelectedVolvo.remove(sender?.tag as Any)
        }
        else {
            sender?.isSelected = true
            if arrVolvoBooked.contains(sender?.tag as Any) {
                self.view.makeToast("Booked")
            }
            else if arrVolvoladies.contains(sender?.tag as Any) {
                self.view.makeToast("Booked")
            }
            else {
                arrSelectedVolvo.add(sender?.tag as Any)
            }
        }
        Book()
        self.lblAmount.text = "$ \(arrSelectedVolvo.count * 80)"
        self.lblTotalAmount.text = "$ \((arrSelectedVolvo.count * 80) + tax)"
        self.tblSeatSelection .reloadData()
    }
    
    func SleeperSeatBook(sender: UIButton?) {
        if sender!.isSelected {
            sender?.isSelected = false
            arrSelectedSleeper.remove(sender?.tag as Any)
        }
        else {
            sender?.isSelected = true
            if arrSleeperBooked.contains(sender?.tag as Any) {
                self.view.makeToast("Booked")
            }
            else if arrSleeperladies.contains(sender?.tag as Any) {
                self.view.makeToast("Booked")
            }
            else {
                arrSelectedSleeper.add(sender?.tag as Any)
            }
        }
        Book()
        self.lblAmount.text = "$ \(arrSelectedSleeper.count * 80)"
        self.lblTotalAmount.text = "$ \((arrSelectedSleeper.count * 80) + tax)"
        self.tblSeatSelection .reloadData()
    }
}
