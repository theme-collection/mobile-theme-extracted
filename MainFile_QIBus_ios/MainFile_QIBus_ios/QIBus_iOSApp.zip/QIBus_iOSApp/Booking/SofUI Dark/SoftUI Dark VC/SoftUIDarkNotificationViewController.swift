//
//  SoftUIDarkNotificationViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 22/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkNotificationViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwConfirmation: UIView!
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var vwWay: UIView!
    @IBOutlet weak var vwTime: UIView!
    @IBOutlet weak var vwSeatNo: UIView!
    
    @IBOutlet weak var tblNotification: UITableView!
    
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblFromTo: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblFromTime: UILabel!
    @IBOutlet weak var lblToTime: UILabel!
    @IBOutlet weak var lblTotalTime: UILabel!
    @IBOutlet weak var lblSeatNo: UILabel!
    @IBOutlet weak var lblTicketNo: UILabel!
    @IBOutlet weak var lblTicketNoValue: UILabel!
    @IBOutlet weak var lblPNRNo: UILabel!
    @IBOutlet weak var lblPNRNoValue: UILabel!
    @IBOutlet weak var lblTotalFare: UILabel!
    @IBOutlet weak var lblTotalFareValue: UILabel!
    @IBOutlet weak var lblSeatNoValue: UILabel!
    
    @IBOutlet weak var btnClose: UIButton!
    
    @IBOutlet weak var imgCompleated: UIImageView!
    @IBOutlet weak var imgBus: UIImageView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrDate = NSMutableArray()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }

    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        arrDate.add("28 May")
        arrDate.add("28 May")
        
        self.view.backgroundColor = UIColor(hexString: PRIMARY_COLORDARK)
//            BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
//            BackgroundSettings.sharedService.backgroundColor
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblFromTo, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblDate, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblFromTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblToTime, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeatNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeatNoValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblTicketNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblTicketNoValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblPNRNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblPNRNoValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalFare, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalFareValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        
        imgBus = setImageTintColor(imgBus, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        
        CornerRadious(view: btnClose, cornerRadus: btnClose.frame.height / 2)
        CornerRadious(view: tblNotification, cornerRadus: 10.0)
        CornerRadiousWithShadow(view: vwConfirmation, cornerRadus: 10.0)
        
        tblNotification.tableFooterView = UIView(frame: .zero)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        vwBackground.addGestureRecognizer(tap)
    }
    
    //MARK: -
    //MARK: - UITableView DataSource & Delegate
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDate.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
               return 150
       }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tblNotification.register(UINib(nibName: "SoftUIDarkNotificationTableCell", bundle: nil), forCellReuseIdentifier: "Cell")
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SoftUIDarkNotificationTableCell
        
        cell.lblDate.text = "28"
        cell.lblMonth.text = "May"
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        vwBackground.isHidden = false
        vwConfirmation.isHidden = false
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCell.EditingStyle.delete) {
            arrDate.removeObject(at: indexPath.row)
            tblNotification.reloadData()
        }
    }
    
    //MARK: -
    //MARK: - UITapGestureRecognizer
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        vwBackground.isHidden = true
        vwConfirmation.isHidden = true
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnClose_Clicked(_ sender: Any) {
        vwBackground.isHidden = true
        vwConfirmation.isHidden = true
    }
}
