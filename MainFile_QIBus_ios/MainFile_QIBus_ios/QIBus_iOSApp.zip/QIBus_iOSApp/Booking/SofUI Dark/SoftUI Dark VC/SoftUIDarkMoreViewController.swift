//
//  SoftUIDarkMoreViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 26/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkMoreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var tblMore: UITableView!
    
    @IBOutlet weak var lblVersion: UILabel!
    
    @IBOutlet weak var constraintTblMoreHeight: NSLayoutConstraint!
    
    //MARK: -
    //MARK: - Variables
    
    let arrMoreImage = ["icoUser", "icoWallet1", "icoCard", "icoRefer", "icoSetting", "icoHelp", "icoLogout"]
    let arrMore = ["Edit Profile", "Wallet", "Card", "Refer & Earn", "Settings", "Help and Support", "Logout"]
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblVersion, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        tblMore.tableFooterView = UIView(frame: .zero)
    }
    
    //MARK: -
    //MARK: - UITableView DataSource & Delegate
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMore.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if IPAD {
            constraintTblMoreHeight.constant = CGFloat(arrMore.count * 80)
            return 80
        }
        else {
            constraintTblMoreHeight.constant = CGFloat(arrMore.count * 100)
            return 100
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tblMore.register(UINib(nibName: "SoftUIDarkMoreTableCell", bundle: nil), forCellReuseIdentifier: "Cell")
        let cell = tblMore.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SoftUIDarkMoreTableCell
                
        cell.imgMore.image = UIImage(named: arrMoreImage[indexPath.row])
        cell.lblMore.text = arrMore[indexPath.row]
        
        cell.imgMore = setImageTintColor(cell.imgMore, tintColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let vc = SoftUIDarkProfileSettingsViewController(nibName: "SoftUIDarkProfileSettingsViewController", bundle: nil)
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 1 {
            let vc = SoftUIDarkWalletViewController(nibName: "SoftUIDarkWalletViewController", bundle: nil)
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 2 {
            let vc = SoftUIDarkCardListViewController(nibName: "SoftUIDarkCardListViewController", bundle: nil)
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 3 {
            let vc = SoftUIDarkReferAndEarnViewController(nibName: "SoftUIDarkReferAndEarnViewController", bundle: nil)
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 4 {
            let vc = SoftUIDarkSettingsViewController(nibName: "SoftUIDarkSettingsViewController", bundle: nil)
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 5 {
            let vc = SoftUIDarkHelpViewController(nibName: "SoftUIDarkHelpViewController", bundle: nil)
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 6 {
            
            // create the alert
            let alert = UIAlertController(title: "Confirmation!", message: "You sure, that you want to logout?", preferredStyle: UIAlertController.Style.alert)
            
            // add the actions (buttons)
            alert.addAction(UIAlertAction(title: "YES", style: .default, handler: { (action) in
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.ChangeColor()
            }))
            
            alert.addAction(UIAlertAction(title: "NO", style: .cancel, handler: { (action) in
                
            }))
            
            // show the alert
            self.present(alert, animated: true, completion: nil)
            
        }
    }

}
