//
//  SoftUIDarkHomeViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 26/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkHomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, CAAnimationDelegate {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgDate: UIImageView!
    @IBOutlet weak var imgSearch: UIImageView!
    @IBOutlet weak var lblAC: UILabel!
    @IBOutlet weak var lblNonAc: UILabel!
    @IBOutlet weak var lblSleeper: UILabel!
    @IBOutlet weak var lblSeater: UILabel!
    @IBOutlet weak var lblNoOfSeat: UILabel!
    @IBOutlet weak var lblNewOffers: UILabel!
    @IBOutlet weak var lblOneWayDate: UILabel!
    @IBOutlet weak var lblRecentSearch: UILabel!
    @IBOutlet weak var lblDateMessage: UILabel!
    
    @IBOutlet weak var txtFromCity: UITextField!
    @IBOutlet weak var txtToCity: UITextField!
    
    @IBOutlet weak var btnSwap: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var btnOneWayDate: UIButton!
    @IBOutlet weak var btnViewAll: UIButton!
    @IBOutlet weak var btnAC: UIButton!
    @IBOutlet weak var btnNonAC: UIButton!
    @IBOutlet weak var btnSleeper: UIButton!
    @IBOutlet weak var btnSeater: UIButton!
    @IBOutlet weak var btnMinus: UIButton!
    @IBOutlet weak var btnPlus: UIButton!
    @IBOutlet weak var btnSearchIcon: UIButton!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var imgAC: UIImageView!
    @IBOutlet weak var imgNonAc: UIImageView!
    @IBOutlet weak var imgSleeper: UIImageView!
    @IBOutlet weak var imgSeater: UIImageView!
    @IBOutlet weak var imgFromCity: UIImageView!
    @IBOutlet weak var imgToCity: UIImageView!
    @IBOutlet weak var imgCalender: UIImageView!
    @IBOutlet weak var imgSelectSeater: UIImageView!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwSearch: UIView!
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var vwDate: UIView!
    @IBOutlet weak var vwDateValues: UIView!
    @IBOutlet weak var vwSearchBtn: UIView!
    
    @IBOutlet weak var cvOffers: UICollectionView!
    @IBOutlet weak var cvRecentSearch: UICollectionView!
    
    //MARK: -
    //MARK: - Variables
    
    var noOfSeat = Int()
    let arrOffer = ["icoSale1", "icoSale2", "icoSale1", "icoSale2", "icoSale1", "icoSale2"]
    let arrColor = [UIColor.yellow, UIColor.blue, UIColor.green, UIColor.blue, UIColor.yellow, UIColor.green]
    let arrRecentSearch = ["New Delhi To Mumbai", "Mumbai To Pune", "Ahmedabad To Mumbai", "Jaipur To New Delhi"]
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpValue()
    }

    //MARK: -
    //MARK: - SetUpView
    
    func SetUpValue() {
//        vwHeader.backgroundColor = UIColor(hexString: PRIMARY_COLOR1)
        vwSearchBtn.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        btnSwap.backgroundColor = BackgroundSettings.sharedService.backgroundColor

        btnAC.showsTouchWhenHighlighted = true
        btnNonAC.showsTouchWhenHighlighted = true
        btnSleeper.showsTouchWhenHighlighted = true
        btnSeater.showsTouchWhenHighlighted = true
        
        noOfSeat = 0
        lblNoOfSeat.text = "\(noOfSeat)"
        btnMinus.isHidden = true
        lblNoOfSeat.isHidden = true
        imgSelectSeater.isHidden = false
        
        let date = Date()
        datePicker.minimumDate = date
        datePicker.backgroundColor = UIColor.white
        datePicker.addTarget(self, action: #selector(labelChange(_:)), for: .valueChanged)
        
        let df = DateFormatter()
        df.dateFormat = "dd-MMM-yyyy"
        lblOneWayDate.text = "\(df.string(from: date))"
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblAC, size: fontSize(size: SIZE_TINY), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblNonAc, size: fontSize(size: SIZE_TINY), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblSleeper, size: fontSize(size: SIZE_TINY), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblSeater, size: fontSize(size: SIZE_TINY), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblNoOfSeat, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblNewOffers, size: fontSize(size: SIZE_LARGE), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblOneWayDate, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblRecentSearch, size: fontSize(size: SIZE_LARGE), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblDateMessage, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnOneWayDate, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnSearch, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnViewAll, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        
        imgSelectSeater = setImageTintColor(imgSelectSeater, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))

        btnMinus = setButtonTintColor(btnMinus, imageName: "icoUpArrowFill", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        btnPlus = setButtonTintColor(btnPlus, imageName: "icoDownArrow", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        if IPAD {
            btnSwap.layer.cornerRadius = 25
        }
        else {
            btnSwap.layer.cornerRadius = btnSwap.frame.height / 2
        }
        btnSwap.layer.shadowColor = (UIColor(hexString: PRIMARY_COLORDARK)).cgColor
        btnSwap.layer.shadowOpacity = 0.8
        btnSwap.layer.shadowRadius = 3.0
        btnSwap.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        
        imgToCity = setImageTintColor(imgToCity, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        imgCalender = setImageTintColor(imgCalender, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        CornerRadiousWithBackground(view: imgFromCity, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: imgFromCity.frame.height / 2)
//        CornerRadious(view: btnSearch, cornerRadus: 5.0)
//        CornerRadious(view: vwSearchBtn, cornerRadus: 5.0)
  //     CornerRadiousWithShadow(view: vwDate, cornerRadus: 5.0)
  //     CornerRadiousWithShadow(view: vwSearch, cornerRadus: 5.0)
        
        vwDateValues.roundCorners([.topLeft, .bottomLeft], radius: 5)
        
        imgAC = setImageTintColor(imgAC, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        lblAC.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        
        imgNonAc = setImageTintColor(imgNonAc, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        lblNonAc.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        
        imgSleeper = setImageTintColor(imgSleeper, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        lblSleeper.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        
        imgSeater = setImageTintColor(imgSeater, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        lblSeater.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        let resizableLogin = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")
        imgSearch.image = resizableLogin
        imgDate.image = resizableLogin
        
        if #available(iOS 11.0, *) {
            self.vwSearchBtn.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        } else {
            // Fallback on earlier versions
        }
        self.vwSearchBtn.layer.cornerRadius = 10.0
    }
    
    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == cvRecentSearch {
            return arrRecentSearch.count
        }
        else {
            return arrOffer.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == cvOffers {
            cvOffers.register(UINib(nibName: "SoftUIDarkOffersCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
            
            let cell = cvOffers.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SoftUIDarkOffersCollectionCell
            
//            cell.imgOffer.image = UIImage(named: arrOffer[indexPath.item])
//            cell.imgOffer.backgroundColor = arrColor[indexPath.item]
            
            return cell
        }
        else {
            cvRecentSearch.register(UINib(nibName: "SoftUIDarkRecentSearchCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
            
            let cell = cvRecentSearch.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SoftUIDarkRecentSearchCollectionCell
            
            cell.lblCty.text = arrRecentSearch[indexPath.item]
            
            cell.btnBook.tag = indexPath.item
            cell.btnBook.addTarget(self, action: #selector(onClickBook(_:)), for: UIControl.Event.touchUpInside)
            
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
         if collectionView == cvOffers {
            return CGSize(width: UIScreen.main.bounds.size.width, height: 130)
        }
        else {
            return CGSize(width: UIScreen.main.bounds.size.width, height: 200)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == cvOffers {
            view.makeToast("Copied")
        }
        else {
            
        }
    }
    
    //MARK: -
    //MARK: - Date Picker Method
    
    @objc func labelChange(_ sender: Any?) {
        let df = DateFormatter()
        df.dateFormat = "dd-MMM-yyyy"
        lblOneWayDate.text = "\(df.string(from: datePicker.date))"
        
    }

    //MARK: -
    //MARK: - Cell UIButton Action Method
    
    @objc func onClickBook(_ sender: UIButton?) {
        let vc = SoftUIDarkBusSearchViewController(nibName: "SoftUIDarkBusSearchViewController", bundle: nil)
        vc.strHeading = arrRecentSearch[sender?.tag ?? 1]
        var arrCity = arrRecentSearch[sender?.tag ?? 1].components(separatedBy: " To ")
        vc.strFromCity = arrCity[0]
        vc.strToCity = arrCity[1]
        self.present(vc, animated: true, completion: nil)
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
     
    @IBAction func btnSearch_Clicked(_ sender: Any) {
        let vc = SoftUIDarkBusSearchViewController(nibName: "SoftUIDarkBusSearchViewController", bundle: nil)
        if txtToCity.text!.count > 0 && txtFromCity.text!.count > 0 {
            vc.strHeading = "\(txtToCity.text ?? "") To \(txtFromCity.text ?? "")"
            vc.strFromCity = txtFromCity.text ?? ""
            vc.strToCity = txtToCity.text ?? ""
        }
        else {
            vc.strHeading = "To"
            vc.strFromCity = ""
            vc.strToCity = ""
        }
        self.present(vc, animated: true, completion: nil)

    }
    
    @IBAction func btnAC_Clicked(_ sender: Any) {
        btnAC.isSelected = !btnAC.isSelected
        if btnAC.isSelected {
            imgAC = setImageTintColor(imgAC, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
            lblAC.textColor = UIColor(hexString: PRIMARY_COLORDARK)
        }
        else {
            imgAC = setImageTintColor(imgAC, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
            lblAC.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        }
    }
    
    @IBAction func lblNonAc_Clicked(_ sender: Any) {
        btnNonAC.isSelected = !btnNonAC.isSelected
        if btnNonAC.isSelected {
            imgNonAc = setImageTintColor(imgNonAc, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
            lblNonAc.textColor = UIColor(hexString: PRIMARY_COLORDARK)
        }
        else {
            imgNonAc = setImageTintColor(imgNonAc, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
            lblNonAc.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        }
    }
    
    @IBAction func btnSleeper_Clicked(_ sender: Any) {
        btnSleeper.isSelected = !btnSleeper.isSelected
        if btnSleeper.isSelected {
            imgSleeper = setImageTintColor(imgSleeper, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
            lblSleeper.textColor = UIColor(hexString: PRIMARY_COLORDARK)
        }
        else {
            imgSleeper = setImageTintColor(imgSleeper, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
            lblSleeper.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        }
    }
    
    @IBAction func btnSeater_Clicked(_ sender: Any) {
        btnSeater.isSelected = !btnSeater.isSelected
        if btnSeater.isSelected {
            imgSeater = setImageTintColor(imgSeater, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
            lblSeater.textColor = UIColor(hexString: PRIMARY_COLORDARK)
        }
        else {
            imgSeater = setImageTintColor(imgSeater, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
            lblSeater.textColor = UIColor(hexString: SECONDARY_TEXT_COLOR_DARK)
        }
    }
    
    @IBAction func btnMinus_Clicked(_ sender: Any) {
        if noOfSeat != 1 {
            noOfSeat -= 1
            lblNoOfSeat.text = "\(noOfSeat)"
            if lblNoOfSeat.text == "1" {
                btnMinus.isHidden = true
            }
        }
        else {
            
        }
    }
    
    @IBAction func btnPlus_Clicked(_ sender: Any) {
        lblNoOfSeat.isHidden = false
        imgSelectSeater.isHidden = true
        
        if noOfSeat != 0 {
            btnMinus.isHidden = false
            noOfSeat += 1
            lblNoOfSeat.text = "\(noOfSeat)"
        }
        else {
            noOfSeat += 1
            lblNoOfSeat.text = "\(noOfSeat)"
            btnMinus.isHidden = true
        }
    }
    
    @IBAction func btnOneWayDate_Clicked(_ sender: Any) {
        vwBackground.isHidden = false
        datePicker.isHidden = false
        btnDone.isHidden = false
    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        vwBackground.isHidden = true
        datePicker.isHidden = true
        btnDone.isHidden = true
    }
    
    @IBAction func btnViewAll_Clicked(_ sender: Any) {
        let vc = SoftUIDarkOffersViewController(nibName: "SoftUIDarkOffersViewController", bundle: nil)
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnSwap_Clicked(_ sender: UIButton) {
        UIView.animate(withDuration: 0.2, animations: {
            self.btnSwap.transform = CGAffineTransform(rotationAngle: (CGFloat(Double.pi)))
        }) { (true) in
            self.btnSwap.transform = CGAffineTransform(rotationAngle: (CGFloat(Double.pi * 2)))
        }
        
        let strTemp:String = txtFromCity.text ?? ""
        txtFromCity.text = txtToCity.text
        txtToCity.text = strTemp
    }
}
