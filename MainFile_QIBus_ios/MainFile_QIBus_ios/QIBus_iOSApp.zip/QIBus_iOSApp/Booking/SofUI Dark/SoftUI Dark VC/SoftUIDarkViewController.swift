//
//  SoftUIDarkViewController.swift
//
//  Created by Goldenmace-E41 on 21/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit
import SwiftGifOrigin

class SoftUIDarkViewController: UIViewController {
    
    //MARK: -
    //MARK: - Otulet
    
    @IBOutlet weak var imgLogo: UIImageView!
    
    //MARK: -
    //MARK: - Veriables
    
    var timer: Timer!
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewWillAppear(_ animated: Bool) {
        //UIApplication.shared.statusBarView?.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Setupview
    
    func SetUpView() {
        imgLogo.image = UIImage.gif(name: "icoLogo")
        
        self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(SoftUIDarkViewController.updateView), userInfo: nil, repeats: true)
    }

    //MARK: -
    //MARK: - Timer method
    
    @objc func updateView(){
            timer.invalidate()
            backgroundColorChanged(color: UIColor(hexString: PRIMARY_COLORDARK))
            let vc = SoftUIDarkConnectViewController(nibName: "SoftUIDarkConnectViewController", bundle: nil)
            self.navigationController?.pushViewController(vc, animated: true)
    }
}

