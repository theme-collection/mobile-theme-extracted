//
//  SoftUIDarkPassengerDetailsTableCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 01/07/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkPassengerDetailsTableCell: UITableViewCell {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgInner3: UIImageView!
    @IBOutlet weak var imgInner2: UIImageView!
    @IBOutlet weak var imgInner1: UIImageView!
    @IBOutlet weak var imgMain: UIImageView!
    @IBOutlet weak var lblPassenger: UILabel!
    @IBOutlet weak var lblSeatNo: UILabel!
    @IBOutlet weak var lblEnterName: UILabel!
    @IBOutlet weak var lblEnterAge: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    
    @IBOutlet weak var vwPassengerDetails: UIView!
    
    @IBOutlet weak var btnArrow: UIButton!
    @IBOutlet weak var btnGender: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPassenger, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeatNo, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblEnterName, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblEnterAge, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblGender, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))

//        CornerRadiousWithShadow(view: vwPassengerDetails, cornerRadus: 5.0)
//        CornerRadiousWithBorder(view: btnGender, color: UIColor(hexString: LIGHT_GRAY), cornerRadus: 5.0, borderWidth: 1)
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")
        imgMain?.image = resizableImage
        
        let resizableLogin1 = SWNinePatchImageFactory.createResizableNinePatchImageNamed("iqbus_Darkui_inner.9")
        imgInner1?.image = resizableLogin1
        imgInner2?.image = resizableLogin1
        imgInner3?.image = resizableLogin1
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
