//
//  SoftUIDarkRecentSearchCollectionCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 09/07/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkRecentSearchCollectionCell: UICollectionViewCell {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgRecent: UIImageView!
    @IBOutlet weak var vwBackground: UIView!
    
    @IBOutlet weak var btnBus: UIButton!
    
    @IBOutlet weak var lblCty: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var btnBook: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()

        CornerRadious(view: vwBackground, cornerRadus: 5.0)
       // Shadow(view: self)
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblCty, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblDate, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnBook, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR_DARK))
        
        btnBus = setButtonTintColor(btnBus, imageName: "icoBus", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        btnBook.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")

        imgRecent?.image = resizableImage
        
        if #available(iOS 11.0, *) {
            self.btnBook.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        } else {
            // Fallback on earlier versions
        }
        self.btnBook.layer.cornerRadius = 10.0
    }

}
