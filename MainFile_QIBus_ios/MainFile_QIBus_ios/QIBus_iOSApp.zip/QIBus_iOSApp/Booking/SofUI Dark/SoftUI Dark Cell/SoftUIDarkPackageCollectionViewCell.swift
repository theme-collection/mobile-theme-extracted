//
//  SoftUIDarkPackageCollectionViewCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 28/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkPackageCollectionViewCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgPkg: UIImageView!
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnBus: UIButton!
    @IBOutlet weak var btnRestorent: UIButton!
    @IBOutlet weak var btnWiifi: UIButton!
    
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var vwLikeBackgroung: UIView!
    
    @IBOutlet weak var imgPackage: UIImageView!
    
    @IBOutlet weak var lblPackageName: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblPriceWithDiscount: UILabel!
    @IBOutlet weak var lblActualPrice: UILabel!
    @IBOutlet weak var lblBooking: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")

               imgPkg?.image = resizableImage
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPackageName, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblDuration, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPriceWithDiscount, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblActualPrice, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblBooking, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        btnHome = setButtonTintColor(btnHome, imageName: "icoHome1", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        btnBus = setButtonTintColor(btnBus, imageName: "icoBus", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        btnRestorent = setButtonTintColor(btnRestorent, imageName: "icoRestorent", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        btnWiifi = setButtonTintColor(btnWiifi, imageName: "icoWifi", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        btnLike = setButtonTintColor(btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        
        CornerRadious(view: btnLike, cornerRadus: btnLike.frame.height / 2)
        CornerRadious(view: vwLikeBackgroung, cornerRadus: vwLikeBackgroung.frame.height / 2)
        CornerRadious(view: imgPackage, cornerRadus: 5.0)
//        Shadow(view: self)
        CornerRadious(view: vwBackground, cornerRadus: 5.0)
        
        let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: lblActualPrice.text ?? "")
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSMakeRange(0, attributeString.length))
        lblActualPrice.attributedText = attributeString
    }
}
