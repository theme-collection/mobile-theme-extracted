//
//  SoftUIDarkVolvoSeatSelectionableViewCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 01/07/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkVolvoSeatSelectionableViewCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var btnSeat1: UIButton!
    @IBOutlet weak var btnSeat2: UIButton!
    @IBOutlet weak var btnSeat3: UIButton!
    @IBOutlet weak var btnSeat4: UIButton!
    
    @IBOutlet weak var lblSeat1: UILabel!
    @IBOutlet weak var lblSeat2: UILabel!
    @IBOutlet weak var lblSeat3: UILabel!
    @IBOutlet weak var lblSeat4: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setFontFamily(PRIMARY_FONT, view: lblSeat1, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeat2, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeat3, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeat4, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        btnSeat1.roundCorners([.topLeft, .topRight], radius: 10.0)
        btnSeat2.roundCorners([.topLeft, .topRight], radius: 10.0)
        btnSeat3.roundCorners([.topLeft, .topRight], radius: 10.0)
        btnSeat4.roundCorners([.topLeft, .topRight], radius: 10.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
