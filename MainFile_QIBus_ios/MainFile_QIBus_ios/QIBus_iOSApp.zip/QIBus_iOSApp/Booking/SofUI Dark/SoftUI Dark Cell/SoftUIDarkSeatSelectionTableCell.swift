//
//  SoftUIDarkSeatSelectionTableCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 29/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkSeatSelectionTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var lblSeat1: UILabel!
    @IBOutlet weak var lblSeat2: UILabel!
    @IBOutlet weak var lblSeat3: UILabel!
    
    @IBOutlet weak var btnSeat1: UIButton!
    @IBOutlet weak var btnSeat2: UIButton!
    @IBOutlet weak var btnSeat3: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setFontFamily(PRIMARY_FONT, view: lblSeat1, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeat2, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeat3, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
        CornerRadious(view: btnSeat1, cornerRadus: 10.0)
        CornerRadious(view: btnSeat2, cornerRadus: 10.0)
        CornerRadious(view: btnSeat3, cornerRadus: 10.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
