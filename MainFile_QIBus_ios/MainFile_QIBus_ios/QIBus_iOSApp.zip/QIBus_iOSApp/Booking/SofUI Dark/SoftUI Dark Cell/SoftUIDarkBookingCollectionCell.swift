//
//  SoftUIDarkBookingCollectionCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 28/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkBookingCollectionCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgBooking: UIImageView!
    @IBOutlet weak var vwWay: UIView!
    @IBOutlet weak var vwTime: UIView!
    @IBOutlet weak var vwSeatNo: UIView!
    
    @IBOutlet weak var lblFromTo: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblConfirmed: UILabel!
    @IBOutlet weak var lblFromTime: UILabel!
    @IBOutlet weak var lblToTime: UILabel!
    @IBOutlet weak var lblTotalTime: UILabel!
    @IBOutlet weak var lblSeatNo: UILabel!
    @IBOutlet weak var lblSeatNoValue: UILabel!
    @IBOutlet weak var lblTicketNo: UILabel!
    @IBOutlet weak var lblTicketNoValue: UILabel!
    @IBOutlet weak var lblPNRNo: UILabel!
    @IBOutlet weak var lblPNRNoValue: UILabel!
    @IBOutlet weak var lblTotalFare: UILabel!
    @IBOutlet weak var lblTotalFareValue: UILabel!
    
    @IBOutlet weak var imgConfirmed: UIImageView!
    @IBOutlet weak var imgCompleated: UIImageView!
    @IBOutlet weak var imgBus: UIImageView!
    
    @IBOutlet weak var btnArrow: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblFromTo, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblDate, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblConfirmed, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: GREEN))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblToTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblFromTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblToTime, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeatNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblSeatNoValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblTicketNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblTicketNoValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT, view: lblPNRNo, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblPNRNoValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalFare, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalFareValue, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLORDARK))
        
        imgBus = setImageTintColor(imgBus, tintColor: UIColor(hexString: PRIMARY_COLORDARK))
        imgConfirmed = setImageTintColor(imgConfirmed, tintColor: UIColor(hexString: GREEN))
        
        CornerRadious(view: imgConfirmed, cornerRadus: imgConfirmed.frame.height / 2)
        
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")

        imgBooking?.image = resizableImage
    }

}
