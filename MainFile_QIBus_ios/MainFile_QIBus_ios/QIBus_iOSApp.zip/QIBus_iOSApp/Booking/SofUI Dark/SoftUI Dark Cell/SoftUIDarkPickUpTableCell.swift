//
//  SoftUIDarkPickUpTableCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 29/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SoftUIDarkPickUpTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwPickup: UIView!
    
    @IBOutlet weak var imgPickup: UIImageView!
    @IBOutlet weak var lblPickup: UILabel!
    @IBOutlet weak var lblLandmark: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPickup, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR_DARK))
        setFontFamily(PRIMARY_FONT, view: lblLandmark, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR_DARK))
        
//        CornerRadiousWithShadow(view: vwPickup, cornerRadus: 5.0)
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12_Dark.9")

        imgPickup?.image = resizableImage
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
