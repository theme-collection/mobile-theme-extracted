//
//  WalletViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 22/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class WalletViewController: UIViewController {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var btnNotification: UIButton!
    
    @IBOutlet weak var lblBadge: UILabel!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblYourBalance: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblReferFriend: UILabel!
    
    @IBOutlet weak var imgAmount: UIImageView!
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        CornerRadiousWithBorder(view: lblBadge, color: UIColor(hexString: QIBUS_PRIMARY_COLOR), cornerRadus: lblBadge.frame.height / 2, borderWidth: 1.0)
        
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblBadge, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblYourBalance, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblAmount, size: fontSize(size: QIBUS_SIZE_XXLARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblReferFriend, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        
        imgAmount = setImageTintColor(imgAmount, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        
        btnNotification.setImage(UIImage.gif(name: "icoGifBell"), for: .normal)
    }
    
    //MARK: -
    //MARK: - UIButton Action Method

    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnNotification_Clicked(_ sender: UIButton) {
        let vc = NotificationViewController(nibName: "NotificationViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnFacebook_Clicked(_ sender: Any) {
        Share(view: self)
    }
    
    @IBAction func btnWhatsapp_Clicked(_ sender: Any) {
        Share(view: self)
    }
    
    @IBAction func btnGoogle_Clicked(_ sender: Any) {
        Share(view: self)
    }
    
    @IBAction func btnTwiter_Clicked(_ sender: Any) {
        Share(view: self)
    }
}
