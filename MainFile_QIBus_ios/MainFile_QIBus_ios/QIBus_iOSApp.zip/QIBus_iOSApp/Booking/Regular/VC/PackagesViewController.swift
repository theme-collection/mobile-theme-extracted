//
//  PackagesViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 26/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit
import AnimatedCollectionViewLayout

class PackagesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var cvNewPackages: UICollectionView!
    @IBOutlet weak var cvPopularPackages: UICollectionView!
    @IBOutlet weak var cvTrendingPackages: UICollectionView!
    
    @IBOutlet weak var lblNewPackage: UILabel!
    @IBOutlet weak var lblPopularPackage: UILabel!
    @IBOutlet weak var lblTrendingPackage: UILabel!
    
    @IBOutlet weak var btnViewAllNewPackage: UIButton!
    @IBOutlet weak var btnViewAllPopularPackage: UIButton!
    @IBOutlet weak var btnViewAllTrendingPackage: UIButton!
    
    //MARK: -
    //MARK: - Variables
    
    let arrLikeNew = NSMutableArray()
    let arrLikePopular = NSMutableArray()
    let arrLikeTrending = NSMutableArray()
    var animator: (LayoutAttributesAnimator, Bool, Int, Int)?
    
    let arrPackage = ["Kerala", "Goa", "Andamans", "Amritsar", "Udaipur"]
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpValue()
    }
    
    //MARK: -
    //MARK: - SetUpView
    
    func SetUpValue() {
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblNewPackage, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblPopularPackage, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblTrendingPackage, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnViewAllNewPackage, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnViewAllPopularPackage, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnViewAllTrendingPackage, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        
        let layout = AnimatedCollectionViewLayout()
        layout.animator = LinearCardAttributesAnimator()
        layout.scrollDirection = .horizontal
        cvNewPackages.collectionViewLayout = layout
        
        let layout1 = AnimatedCollectionViewLayout()
        layout1.animator = LinearCardAttributesAnimator()
        layout1.scrollDirection = .horizontal
        cvPopularPackages.collectionViewLayout = layout1
        
        let layout2 = AnimatedCollectionViewLayout()
        layout2.animator = LinearCardAttributesAnimator()
        layout2.scrollDirection = .horizontal
        cvTrendingPackages.collectionViewLayout = layout2
        
    }

    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == cvNewPackages {
            cvNewPackages.register(UINib(nibName: "PackageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
            let cell = cvNewPackages.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! PackageCollectionViewCell
            
            cell.lblPackageName.text = arrPackage[indexPath.item]
            cell.imgPackage.image = UIImage(named: arrPackage[indexPath.item])
            
            cell.btnLike.tag = indexPath.item
            cell.btnLike.addTarget(self, action: #selector(onClickLikeNewPackage(_:)), for: UIControl.Event.touchUpInside)
            
            if arrLikeNew.contains(indexPath.item) {
                cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeartFill", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
            }
            else {
                cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
            }
            
            return cell
        }
        else if collectionView == cvPopularPackages {
            cvPopularPackages.register(UINib(nibName: "PackageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
            let cell = cvPopularPackages.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! PackageCollectionViewCell
            
            cell.lblPackageName.text = arrPackage[indexPath.item]
            cell.imgPackage.image = UIImage(named: arrPackage[indexPath.item])
            
            cell.btnLike.tag = indexPath.item
            cell.btnLike.addTarget(self, action: #selector(onClickLikePopularPackage(_:)), for: UIControl.Event.touchUpInside)
            
            if arrLikePopular.contains(indexPath.item) {
                cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeartFill", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
            }
            else {
                cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
            }
            
            return cell
        }
        else {
            cvTrendingPackages.register(UINib(nibName: "PackageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
            let cell = cvTrendingPackages.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! PackageCollectionViewCell
            
            cell.lblPackageName.text = arrPackage[indexPath.item]
            cell.imgPackage.image = UIImage(named: arrPackage[indexPath.item])
            
            cell.btnLike.tag = indexPath.item
            cell.btnLike.addTarget(self, action: #selector(onClickLikeTrendingPackage(_:)), for: UIControl.Event.touchUpInside)            
            
            if arrLikeTrending.contains(indexPath.item) {
                cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeartFill", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
            }
            else {
                cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
            }
            
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if IPAD {
            return CGSize(width: cvNewPackages.frame.width, height: 290)
        }
        else {
            return CGSize(width: cvNewPackages.frame.width, height: 235)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = BusSearchViewController(nibName: "BusSearchViewController", bundle: nil)
        vc.strHeading = arrPackage[indexPath.item]
        self.present(vc, animated: true, completion: nil)
    }
    
    //MARK: -
    //MARK: - Cell UIButton Action Method
    
    @objc func onClickLikeNewPackage(_ sender: UIButton?) {
        if sender!.isSelected {
            sender?.isSelected = false
            arrLikeNew.remove(sender?.tag as Any)
        }
        else {
            sender?.isSelected = true
            arrLikeNew.add(sender?.tag as Any)
        }
        cvNewPackages.reloadData()
    }
    
    @objc func onClickLikePopularPackage(_ sender: UIButton?) {
        if sender!.isSelected {
            sender?.isSelected = false
            arrLikePopular.remove(sender?.tag as Any)
        }
        else {
            sender?.isSelected = true
            arrLikePopular.add(sender?.tag as Any)
        }
        cvPopularPackages.reloadData()
    }
    
    @objc func onClickLikeTrendingPackage(_ sender: UIButton?) {
        if sender!.isSelected {
            sender?.isSelected = false
            arrLikeTrending.remove(sender?.tag as Any)
        }
        else {
            sender?.isSelected = true
            arrLikeTrending.add(sender?.tag as Any)
        }
        cvTrendingPackages.reloadData()
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnViewAllNewPackage_Clicked(_ sender: Any) {
        let vc = PackageListViewController(nibName: "PackageListViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnViewAllPopularPackage_Clicked(_ sender: Any) {
        let vc = PackageListViewController(nibName: "PackageListViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnViewAllTrendingPackage_Clicked(_ sender: Any) {
        let vc = PackageListViewController(nibName: "PackageListViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
}
