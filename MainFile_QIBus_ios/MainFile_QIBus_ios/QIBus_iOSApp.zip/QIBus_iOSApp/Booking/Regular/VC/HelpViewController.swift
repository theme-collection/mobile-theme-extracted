//
//  HelpViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 29/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class HelpViewController: UIViewController {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    
    @IBOutlet weak var btnNotification: UIButton!
    
    @IBOutlet weak var lblBadge: UILabel!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblFillDetails: UILabel!
    
    @IBOutlet weak var vwContactNo: UIView!
    @IBOutlet weak var vwEmail: UIView!
    @IBOutlet weak var vwDesc: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var btnSubmit: UIButton!
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }

    //MARK: -
    //MARK: - SetUpView

    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblBadge, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblFillDetails, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnSubmit, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        CornerRadiousWithShadow(view: vwContactNo, cornerRadus: 5.0)
        CornerRadiousWithShadow(view: vwEmail, cornerRadus: 5.0)
        CornerRadiousWithShadow(view: vwDesc, cornerRadus: 5.0)
        CornerRadiousWithBackground(view: btnSubmit, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        CornerRadiousWithBorder(view: lblBadge, color: UIColor(hexString: QIBUS_PRIMARY_COLOR), cornerRadus: lblBadge.frame.height / 2, borderWidth: 1.0)
        
        btnNotification.setImage(UIImage.gif(name: "icoGifBell"), for: .normal)
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnSubmit_Clicked(_ sender: Any) {
    }
    
    @IBAction func btnNotification_Clicked(_ sender: UIButton) {
        let vc = NotificationViewController(nibName: "NotificationViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
}
