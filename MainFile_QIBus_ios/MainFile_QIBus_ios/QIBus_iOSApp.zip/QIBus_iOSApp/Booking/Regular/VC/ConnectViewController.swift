//
//  ConnectViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 21/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit
import CountryPicker

class ConnectViewController: UIViewController, CountryPickerDelegate, UITextFieldDelegate {

    //MARK: -
    //MARK: - Otulets
    
    @IBOutlet weak var btnContinue: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    
    @IBOutlet weak var lblPhoneCode: UILabel!
    @IBOutlet weak var lblYouWantTo: UILabel!
    @IBOutlet weak var lblTravel: UILabel!
    @IBOutlet weak var lblConnectUsing: UILabel!
    
    @IBOutlet weak var vwMobileNumber: UIView!
    
    @IBOutlet weak var txtPhoneNo: UITextField!
    
    @IBOutlet weak var imgDropDown: UIImageView!
    
    @IBOutlet weak var phoneNoPicker: CountryPicker!
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewWillAppear(_ animated: Bool) {
//        UIApplication.shared.statusBarView?.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        // Set fonts.
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblYouWantTo, size: fontSize(size: QIBUS_SIZE_XLARGE), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblConnectUsing, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblPhoneCode, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblTravel, size: fontSize(size: QIBUS_SIZE_XXXLARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnContinue, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        // Set corner radious
        CornerRadiousWithBackground(view: btnContinue, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        CornerRadiousWithBorder(view: vwMobileNumber, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0, borderWidth: 1.0)
        
        // Set tint color
        imgDropDown = setImageTintColor(imgDropDown, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR, alpha: 0.4))
        
        let locale = Locale.current
        let code = (locale as NSLocale).object(forKey: NSLocale.Key.countryCode) as! String?
        phoneNoPicker.setCountry(code!)
        phoneNoPicker.backgroundColor = .white
    }
    
    // a picker item was selected
    func countryPhoneCodePicker(_ picker: CountryPicker, didSelectCountryWithName name: String, countryCode: String, phoneCode: String, flag: UIImage) {
        lblPhoneCode.text = phoneCode
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        phoneNoPicker.isHidden = true
        btnDone.isHidden = true
    }
    
    //MARK: -
    //MARK: - UIButton Action Methods
    
    @IBAction func btnPhoneCode_Clicked(_ sender: Any) {
        view.endEditing(true)
        phoneNoPicker.isHidden = false
        btnDone.isHidden = false
        //init Picker
        let theme = CountryViewTheme(countryCodeTextColor: .black, countryNameTextColor: .black, rowBackgroundColor: .white, showFlagsBorder: false)
        phoneNoPicker.theme = theme
        phoneNoPicker.countryPickerDelegate = self
        phoneNoPicker.showPhoneNumbers = true
    }
    
    @IBAction func btnContinue_Clicked(_ sender: Any) {
        let vc = VerificationViewController(nibName: "VerificationViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        phoneNoPicker.isHidden = true
        btnDone.isHidden = true
    }
}
