//
//  ViewController.swift

import UIKit
import SwiftGifOrigin

class ViewController: UIViewController {
    
    //MARK: -
    //MARK: - Otulet
    
    @IBOutlet weak var imgLogo: UIImageView!
    
    //MARK: -
    //MARK: - Veriables
    
    var timer: Timer!
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewWillAppear(_ animated: Bool) {
//        UIApplication.shared.statusBarView?.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Setupview
    
    func SetUpView() {
        imgLogo.image = UIImage.gif(name: "icoLogo")
        
        self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(ViewController.updateView), userInfo: nil, repeats: true)
    }

    //MARK: -
    //MARK: - Timer method
    
    @objc func updateView(){
        timer.invalidate()
        backgroundColorChanged(color: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        let vc = SelectQIBusThemeViewController(nibName: "SelectQIBusThemeViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

