//
//  BusSearchViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 25/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit
import Cosmos

class BusSearchViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIPickerViewDelegate, UIPickerViewDataSource {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var sliderPrice: UISlider!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwFilterBackground: UIView!
    @IBOutlet var vwFilter: UIView!
    @IBOutlet weak var vwRating: CosmosView!
    @IBOutlet var vwPicker: UIView!
    @IBOutlet weak var vwPickerBackground: UIView!
    @IBOutlet weak var vwDate: UIView!
    @IBOutlet weak var vwBackground: UIView!
    
    @IBOutlet weak var btnApply: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnPreviousDate: UIButton!
    @IBOutlet weak var btnNextDate: UIButton!
    
    @IBOutlet weak var pickerBusType: UIPickerView!
    
    @IBOutlet weak var cvBusList: UICollectionView!
    
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblBusAvailable: UILabel!
    @IBOutlet weak var lblBusType: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblMinPrice: UILabel!
    @IBOutlet weak var lblMaxPrice: UILabel!
    @IBOutlet weak var lblStarRating: UILabel!
    @IBOutlet weak var lblBusTypeHeading: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    //MARK: -
    //MARK: - Variables
    
    var arrBusType = ["AC", "Non AC", "Normal"]
    var arrBus = ["Seater", "Sleeper", "Seater"]
    var strHeading = String()
    var strFromCity = String()
    var strToCity = String()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        btnApply.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        lblHeading.text = strHeading
        
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblBusAvailable, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblPrice, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblMinPrice, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblMaxPrice, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblStarRating, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblBusTypeHeading, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblBusType, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnApply, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblDate, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        lblMaxPrice.text = "\(Int(sliderPrice.value))"
        
        vwRating.settings.fillMode = .precise
        vwRating.settings.minTouchRating = 0
        
        CornerRadious(view: btnApply, cornerRadus: 5.0)
        CornerRadiousWithShadow(view: vwDate, cornerRadus: 5.0)
        CornerRadious(view: vwBackground, cornerRadus: 10.0)
        
        let date = Date()
        let df = DateFormatter()
        df.dateFormat = "dd-MMM-yyyy"
        lblDate.text = "\(df.string(from: date))"
        
        if IPAD {
            self.vwFilter.frame = CGRect(x: 0, y: self.view.frame.height - 400, width: self.view.frame.width, height: 400)
        }
        else {
            self.vwFilter.frame = CGRect(x: 0, y: self.view.frame.height - self.vwFilter.frame.height, width: self.view.frame.width, height: self.vwFilter.frame.height)
        }
    }
    
    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrBus.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cvBusList.register(UINib(nibName: "BusSearchNewCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        
        let cell = cvBusList.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! BusSearchNewCollectionCell
    
        cell.lblBusType.text = arrBus[indexPath.item]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if IPAD {
            return CGSize(width: UIScreen.main.bounds.size.width-32, height: 200)
        }
        else {
            return CGSize(width: UIScreen.main.bounds.size.width-16, height: 170)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = SeatSelectionViewController(nibName: "SeatSelectionViewController", bundle: nil)
        vc.strBus = arrBus[indexPath.item]
        vc.strFromCity = strFromCity
        vc.strToCity = strToCity
        present(vc, animated: true, completion: nil)
    }
    
    //MARK: -
    //MARK: - Slider Method
    
    @IBAction func sliderPrice_Clicked(_ sender: UISlider) {
        let price:Int = Int(sender.value)
        lblMaxPrice.text = "\(price)"
    }
    
    //MARK: -
    //MARK: - Picker View Delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrBusType.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrBusType[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblBusType.text = arrBusType[row]
    }
    
    //MARK: -
    //MARK: - UITapGestureRecognizer
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        UIView.animate(withDuration: 0.5) {
            self.vwFilter.frame = CGRect(x: 0, y: self.view.frame.height, width: self.view.frame.width, height: self.vwFilter.frame.height)
        }
        vwFilter.removeFromSuperview()
        vwFilterBackground.isHidden = true
        vwFilter.isHidden = true
        
        vwPicker.isHidden = true
        vwPickerBackground.isHidden = true
        vwPicker.removeFromSuperview()
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnFilter_Clicked(_ sender: Any) {
        vwFilterBackground.isHidden = false
        vwFilter.isHidden = false
        vwPickerBackground.isHidden = true
        
        self.view.addSubview(vwFilter)
        UIView.animate(withDuration: 0.2) {
            if IPAD {
                self.vwFilter.frame = CGRect(x: 0, y: self.view.frame.height - 400, width: self.view.frame.width, height: 400)
            }
            else {
                self.vwFilter.frame = CGRect(x: 0, y: self.view.frame.height - self.vwFilter.frame.height, width: self.view.frame.width, height: self.vwFilter.frame.height)
            }
        }
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        vwFilterBackground.addGestureRecognizer(tap)
    }
    
    @IBAction func btnBusType_Clicked(_ sender: Any) {
        self.vwPicker.frame = CGRect(x: 0, y: self.view.frame.height - self.vwPicker.frame.height, width: self.view.frame.width, height: self.vwPicker.frame.height)
        self.view.addSubview(vwPicker)
        vwPicker.isHidden = false
        vwPickerBackground.isHidden = false
    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        vwPicker.isHidden = true
        vwPickerBackground.isHidden = true
        vwPicker.removeFromSuperview()
    }
    
    @IBAction func btnApply_Clicked(_ sender: Any) {
        UIView.animate(withDuration: 0.5) {
            self.vwFilter.frame = CGRect(x: 0, y: self.view.frame.height, width: self.view.frame.width, height: self.vwFilter.frame.height)
        }
        vwFilter.removeFromSuperview()
        vwFilterBackground.isHidden = true
        vwFilter.isHidden = true
        
        vwPicker.isHidden = true
        vwPickerBackground.isHidden = true
        vwPicker.removeFromSuperview()
    }
    
    @IBAction func btnPreviousDate_Clicked(_ sender: Any) {
        convertNextDate(dateString: lblDate.text ?? "", isNext: false)
    }
    
    @IBAction func btnNextDate_Clicked(_ sender: Any) {
        convertNextDate(dateString: lblDate.text ?? "", isNext: true)
    }
    
    //MARK: -
    //MARK: - Other methods
    
    func convertNextDate(dateString : String, isNext: Bool){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        let myDate = dateFormatter.date(from: dateString)!
        
        if isNext {
            let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: myDate)
            lblDate.text = dateFormatter.string(from: tomorrow!)
        }
        else {
            let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: myDate)
            lblDate.text = dateFormatter.string(from: yesterday!)
        }
        
    }
}
