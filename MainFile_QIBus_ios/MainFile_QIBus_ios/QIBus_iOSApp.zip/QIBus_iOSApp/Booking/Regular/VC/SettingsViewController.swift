//
//  SettingsViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 06/07/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwEmail: UIView!
    @IBOutlet weak var vwContactNo: UIView!
    @IBOutlet weak var vwLanguage: UIView!
    @IBOutlet weak var vwCountry: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var lblBadge: UILabel!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblEmailSetting: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblEmailNotification: UILabel!
    @IBOutlet weak var lblContactSetting: UILabel!
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var lblNumberNotification: UILabel!
    @IBOutlet weak var lblLanguageSetting: UILabel!
    @IBOutlet weak var lblLanguage: UILabel!
    @IBOutlet weak var lblLanguageValue: UILabel!
    @IBOutlet weak var lblCountrySetting: UILabel!
    @IBOutlet weak var lblCountry: UILabel!
    @IBOutlet weak var lblCountryValue: UILabel!
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    
    @IBOutlet weak var btnDropDown: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnCountryDropDown: UIButton!
    @IBOutlet weak var btnNotification: UIButton!
    
    @IBOutlet weak var switchEmail: UISwitch!
    @IBOutlet weak var switchContact: UISwitch!
    
    @IBOutlet weak var pickerLanguage: UIPickerView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrLanguage = ["English", "Arabic", "French"];
    let arrCountry = ["India", "UAE", "England", "Australia"];
    var strPickerIdentifier = String()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        strPickerIdentifier = ""
        
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblBadge, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblEmailSetting, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblEmail, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblEmailNotification, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblContactSetting, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblMobileNo, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblNumberNotification, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblLanguageSetting, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblLanguage, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblLanguageValue, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: txtEmail, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: txtMobileNo, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblCountrySetting, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblCountry, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblCountryValue, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        switchEmail.thumbTintColor = UIColor(hexString: QIBUS_PRIMARY_COLOR)
        switchContact.thumbTintColor = UIColor(hexString: QIBUS_PRIMARY_COLOR)
        
        pickerLanguage.backgroundColor = .white
        
        btnDropDown = setButtonTintColor(btnDropDown, imageName: "icoDownArrow", state: .normal, tintColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        btnCountryDropDown = setButtonTintColor(btnCountryDropDown, imageName: "icoDownArrow", state: .normal, tintColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        
        CornerRadiousWithShadow(view: vwEmail, cornerRadus: 5.0)
        CornerRadiousWithShadow(view: vwContactNo, cornerRadus: 5.0)
        CornerRadiousWithShadow(view: vwLanguage, cornerRadus: 5.0)
        CornerRadiousWithShadow(view: vwCountry, cornerRadus: 5.0)
        CornerRadiousWithBorder(view: lblBadge, color: UIColor(hexString: QIBUS_PRIMARY_COLOR), cornerRadus: lblBadge.frame.height / 2, borderWidth: 1.0)
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        
        btnNotification.setImage(UIImage.gif(name: "icoGifBell"), for: .normal)
    }
    
    //MARK: -
    //MARK: - Picker View Delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if strPickerIdentifier == "language" {
            return arrLanguage.count
        }
        else if strPickerIdentifier == "country" {
            return arrCountry.count
        }
        else {
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if strPickerIdentifier == "language" {
            return arrLanguage[row]
        }
        else if strPickerIdentifier == "country" {
            return arrCountry[row]
        }
        else {
            return nil
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if strPickerIdentifier == "language" {
            lblLanguageValue.text = arrLanguage[row]
        }
        else if strPickerIdentifier == "country" {
            lblCountryValue.text = arrCountry[row]
        }
        else {
            lblCountryValue.text = ""
        }
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func vwBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnLanguage_Clicked(_ sender: Any) {
        strPickerIdentifier = "language"
        pickerLanguage.reloadAllComponents()
        pickerLanguage.isHidden = false
        btnDone.isHidden = false
    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        pickerLanguage.isHidden = true
        btnDone.isHidden = true
    }
    
    @IBAction func btnCountry_Clicked(_ sender: Any) {
        strPickerIdentifier = "country"
        pickerLanguage.reloadAllComponents()
        pickerLanguage.isHidden = false
        btnDone.isHidden = false
    }
    
    @IBAction func btnNotification_Clicked(_ sender: UIButton) {
        let vc = NotificationViewController(nibName: "NotificationViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
}
