//
//  VerificationViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 22/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class VerificationViewController: UIViewController, UITextFieldDelegate {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblVerify: UILabel!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblCountDown: UILabel!
    @IBOutlet weak var lblNo1: UILabel!
    @IBOutlet weak var lblNo2: UILabel!
    @IBOutlet weak var lblNo3: UILabel!
    @IBOutlet weak var lblNo4: UILabel!
    
    @IBOutlet weak var txtNo1: UITextField!
    @IBOutlet weak var txtNo2: UITextField!
    @IBOutlet weak var txtNo3: UITextField!
    @IBOutlet weak var txtNo4: UITextField!
    
    @IBOutlet weak var btnVerify: UIButton!
    @IBOutlet weak var btnResend: UIButton!
    
    //MARK: -
    //MARK: - Variables
    
    var count = Int()
    var timer = Timer()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewWillAppear(_ animated: Bool) {
//        UIApplication.shared.statusBarView?.backgroundColor = BackgroundSettings.sharedService.backgroundColor
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        self.btnVerify.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        SetUpView()
    }

    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblMessage, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblVerify, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblCountDown, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: btnResend, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        if IPAD {
            CornerRadious(view: btnVerify, cornerRadus: 20)
        }
        else {
            CornerRadious(view: btnVerify, cornerRadus: btnVerify.frame.height / 2)
        }
        btnResend.isHidden = true
        lblCountDown.isHidden = false
        CountDownTimer()
    }
    
    //MARK: -
    //MARK: - Other methods
    
    func CountDownTimer() {
        count = 60
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
    }
    
    @objc func update() {
        if(count > 0) {
            btnResend.isHidden = true
            lblCountDown.isHidden = false
            count = count - 1
            lblCountDown.text = "\(count) seconds left"
        }
        else {
            timer.invalidate()
            btnResend.isHidden = false
            lblCountDown.isHidden = true
            lblCountDown.text = ""
        }
    }
    
    //MARK: -
    //MARK: - UITextField Delegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == txtNo1 {
            lblNo1.backgroundColor = UIColor(hexString: QIBUS_PRIMARY_COLOR)
            lblNo2.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo3.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo4.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
        }
        else if textField == txtNo2 {
            lblNo2.backgroundColor = UIColor(hexString: QIBUS_PRIMARY_COLOR)
            lblNo1.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo3.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo4.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
        }
        else if textField == txtNo3 {
            lblNo2.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo3.backgroundColor = UIColor(hexString: QIBUS_PRIMARY_COLOR)
            lblNo1.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo4.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
        }
        else if textField == txtNo4 {
            lblNo4.backgroundColor = UIColor(hexString: QIBUS_PRIMARY_COLOR)
            lblNo3.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo2.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            lblNo1.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if let char = string.cString(using: String.Encoding.utf8) {
            let isBackSpace = strcmp(char, "\\b")
            if (isBackSpace == -92) {
                print("Backspace was pressed")
            }
        }
        
        if !(string == "") {
            textField.text = string
            if textField.isEqual(txtNo1) {
                txtNo2.becomeFirstResponder()
            } else if textField.isEqual(txtNo2) {
                txtNo3.becomeFirstResponder()
            } else if textField.isEqual(txtNo3) {
                txtNo4.becomeFirstResponder()
            } else if textField.isEqual(txtNo4) {
                textField.resignFirstResponder()
                lblNo4.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
                lblNo3.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
                lblNo2.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
                lblNo1.backgroundColor = UIColor(hexString: QIBUS_LIGHT_GRAY)
            } else {
            }
            return false
        }
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (textField.text?.count ?? 0) > 0 {
            textField.text = ""
        }
        return true
    }

    
    //MARK: -
    //MARK: - UIButton Action Method

    @IBAction func btnBack_Clicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnResendOTP_Clicked(_ sender: Any) {
        CountDownTimer()
    }
    
    @IBAction func btnVerify_Clicked(_ sender: Any) {
        let vc = TabBarViewController(nibName: "TabBarViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
