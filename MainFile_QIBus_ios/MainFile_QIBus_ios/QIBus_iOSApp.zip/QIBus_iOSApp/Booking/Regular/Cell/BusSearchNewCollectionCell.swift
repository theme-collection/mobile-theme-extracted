//
//  BusSearchNewCollectionCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 04/07/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class BusSearchNewCollectionCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwTravelsName: UIView!
    @IBOutlet weak var vwCellBackground: UIView!
    
    @IBOutlet weak var lblTravelsName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblFromTime: UILabel!
    @IBOutlet weak var lblFromAM: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblHolds: UILabel!
    @IBOutlet weak var lblToTime: UILabel!
    @IBOutlet weak var lblToAm: UILabel!
    @IBOutlet weak var lblRatting: UILabel!
    @IBOutlet weak var lblBusType: UILabel!
    
    @IBOutlet weak var imgBus1: UIImageView!
    @IBOutlet weak var imgBus2: UIImageView!
    
    @IBOutlet weak var btnTime: UIButton!
    @IBOutlet weak var btnStar: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
        CornerRadiousWithBackground(view: vwTravelsName, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        CornerRadious(view: vwCellBackground, cornerRadus: 5.0)
        Shadow(view: self)
        CornerRadiousWithBackground(view: btnTime, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblTravelsName, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblAmount, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblFromTime, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblFromAM, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblToTime, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblToAm, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblDuration, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblHolds, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblRatting, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblBusType, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnTime, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        
        imgBus1 = setImageTintColor(imgBus1, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        imgBus2 = setImageTintColor(imgBus2, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
    }

}
