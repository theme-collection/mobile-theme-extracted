//
//  MoreTableCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 28/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class MoreTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwMoreListing: UIView!
    
    @IBOutlet weak var imgMore: UIImageView!
    
    @IBOutlet weak var lblMore: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblMore, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
                
        CornerRadiousWithShadow(view: vwMoreListing, cornerRadus: 5.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
