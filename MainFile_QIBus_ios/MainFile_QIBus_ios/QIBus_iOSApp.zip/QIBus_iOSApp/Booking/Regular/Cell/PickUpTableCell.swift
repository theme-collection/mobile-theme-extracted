//
//  PickUpTableCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 29/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class PickUpTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwPickup: UIView!
    
    @IBOutlet weak var lblPickup: UILabel!
    @IBOutlet weak var lblLandmark: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblPickup, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblTime, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblLandmark, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        
        CornerRadiousWithShadow(view: vwPickup, cornerRadus: 5.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
