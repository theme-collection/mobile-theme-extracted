//
//  PackageCollectionViewCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 28/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class PackageCollectionViewCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnBus: UIButton!
    @IBOutlet weak var btnRestorent: UIButton!
    @IBOutlet weak var btnWiifi: UIButton!
    
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var vwLikeBackgroung: UIView!
    
    @IBOutlet weak var imgPackage: UIImageView!
    
    @IBOutlet weak var lblPackageName: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblPriceWithDiscount: UILabel!
    @IBOutlet weak var lblActualPrice: UILabel!
    @IBOutlet weak var lblBooking: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblPackageName, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblDuration, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblPriceWithDiscount, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblActualPrice, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblBooking, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        
        btnHome = setButtonTintColor(btnHome, imageName: "icoHome1", state: .normal, tintColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        btnBus = setButtonTintColor(btnBus, imageName: "icoBus", state: .normal, tintColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        btnRestorent = setButtonTintColor(btnRestorent, imageName: "icoRestorent", state: .normal, tintColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        btnWiifi = setButtonTintColor(btnWiifi, imageName: "icoWifi", state: .normal, tintColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        
        btnLike = setButtonTintColor(btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        
        CornerRadious(view: btnLike, cornerRadus: btnLike.frame.height / 2)
        CornerRadious(view: vwLikeBackgroung, cornerRadus: vwLikeBackgroung.frame.height / 2)
        CornerRadious(view: imgPackage, cornerRadus: 5.0)
        Shadow(view: self)
        CornerRadious(view: vwBackground, cornerRadus: 5.0)
        
        let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: lblActualPrice.text ?? "")
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSMakeRange(0, attributeString.length))
        lblActualPrice.attributedText = attributeString
    }
}
