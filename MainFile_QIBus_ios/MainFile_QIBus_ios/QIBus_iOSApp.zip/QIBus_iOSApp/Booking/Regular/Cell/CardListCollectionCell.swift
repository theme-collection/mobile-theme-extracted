//
//  CardListCollectionCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 29/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class CardListCollectionCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwCard: UIView!
    
    @IBOutlet weak var lblCardType: UILabel!
    @IBOutlet weak var lblCardNo: UILabel!
    @IBOutlet weak var lblValid: UILabel!
    @IBOutlet weak var lblValidDate: UILabel!
    @IBOutlet weak var lblCardHolderName: UILabel!
    
    @IBOutlet weak var imgCard: UIImageView!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblCardType, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_BOLD, view: lblCardNo, size: fontSize(size: QIBUS_SIZE_LARGE), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblValidDate, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblCardHolderName, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: .white)
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblValid, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: .white)

        CornerRadious(view: vwCard, cornerRadus: 5.0)
        Shadow(view: self)
    }
}
