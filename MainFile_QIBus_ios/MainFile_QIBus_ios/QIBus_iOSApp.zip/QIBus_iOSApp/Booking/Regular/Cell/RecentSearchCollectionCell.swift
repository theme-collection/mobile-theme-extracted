//
//  RecentSearchCollectionCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 09/07/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class RecentSearchCollectionCell: UICollectionViewCell {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwBackground: UIView!
    
    @IBOutlet weak var btnBus: UIButton!
    
    @IBOutlet weak var lblCty: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var btnBook: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()

        CornerRadious(view: vwBackground, cornerRadus: 5.0)
        Shadow(view: self)
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblCty, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblDate, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: btnBook, size: fontSize(size: QIBUS_SIZE_MEDIUM), textColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR))
        
        btnBus = setButtonTintColor(btnBus, imageName: "icoBus", state: .normal, tintColor: UIColor(hexString: QIBUS_PRIMARY_COLOR))
        btnBook.backgroundColor = BackgroundSettings.sharedService.backgroundColor
    }

}
