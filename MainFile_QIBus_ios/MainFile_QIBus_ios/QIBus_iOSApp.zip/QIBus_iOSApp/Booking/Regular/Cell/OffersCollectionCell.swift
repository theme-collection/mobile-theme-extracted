//
//  OffersCollectionCell.swift
//  Booking
//
//  Created by Goldenmace-E41 on 26/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class OffersCollectionCell: UICollectionViewCell {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgOffer: UIImageView!
    
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblValidity: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    
    @IBOutlet weak var vwBackground: UIView!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        CornerRadious(view: vwBackground, cornerRadus: 5.0)
        Shadow(view: self)
        
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblMessage, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT, view: lblValidity, size: fontSize(size: QIBUS_SIZE_SMALL), textColor: UIColor(hexString: QIBUS_SECONDARY_TEXT_COLOR))
        setFontFamily(QIBUS_PRIMARY_FONT_SEMIBOLD, view: lblCode, size: fontSize(size: QIBUS_SIZE_MSMALL), textColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR))
    }

}
