//
//  Configration.swift

import Foundation
import UIKit

//QIBus
let QIBUS_PRIMARY_COLOR = "#eb4b51"

let QIBUS_PRIMARY_TEXT_COLOR = "#464545"
let QIBUS_SECONDARY_TEXT_COLOR = "#747474"
let QIBUS_BTN_TEXT_COLOR = "#ffffff"
let QIBUS_GREEN = "#239811"
let QIBUS_DARK_GRAY = "#949494"
let QIBUS_LIGHT_GRAY = "#c9c9c9"

let QIBUS_PRIMARY_FONT = "Roboto-Regular"
let QIBUS_PRIMARY_FONT_SEMIBOLD = "Roboto-Bold"
let QIBUS_PRIMARY_FONT_BOLD = "Roboto-Black"

let QIBUS_SIZE_XXXLARGE:Float = 35
let QIBUS_SIZE_XXLARGE:Float = 30
let QIBUS_SIZE_XLARGE:Float = 24
let QIBUS_SIZE_LARGE:Float = 20
let QIBUS_SIZE_NORMAL:Float = 18
let QIBUS_SIZE_MEDIUM:Float = 16
let QIBUS_SIZE_MSMALL:Float = 14
let QIBUS_SIZE_SMALL:Float = 12
let QIBUS_SIZE_TINY:Float = 10

// SOFUI
// Primary color for app
let PRIMARY_COLOR = "#9292EE"

// Primary color for app
let PRIMARY_COLORDARK = "#DDDDFF"//9292EE
let PRIMARY_COLOR1 = "#191925"
// TextColor
let PRIMARY_TEXT_COLOR_DARK = "#ffffff"
let SECONDARY_TEXT_COLOR_DARK = "#ffffff"
let BTN_TEXT_COLOR_DARK = "#ffffff"

// TextColor
let PRIMARY_TEXT_COLOR = "#464545"
let SECONDARY_TEXT_COLOR = "#747474"
let BTN_TEXT_COLOR = "#ffffff"
let GREEN = "#239811"
let DARK_GRAY = "#949494"
let LIGHT_GRAY = "#c9c9c9"

let BTN_TEXT_COLOR_SOFT = "#000000"

// App Font
let PRIMARY_FONT = "Roboto-Regular"
let PRIMARY_FONT_SEMIBOLD = "Roboto-Bold"
let PRIMARY_FONT_BOLD = "Roboto-Black"

//Text Size
let SIZE_XXXLARGE:Float = 35
let SIZE_XXLARGE:Float = 30
let SIZE_XLARGE:Float = 24
let SIZE_LARGE:Float = 20
let SIZE_NORMAL:Float = 18
let SIZE_MEDIUM:Float = 16
let SIZE_MSMALL:Float = 14
let SIZE_SMALL:Float = 12
let SIZE_TINY:Float = 10

let SCREEN_SIZE = UIScreen.main.bounds.size

let IPAD = UI_USER_INTERFACE_IDIOM() == .pad
