//
//  HelperMethods.swift
//  Booking
//
//  Created by Goldenmace-E41 on 21/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import Foundation
import UIKit

func backgroundColorChanged(color : UIColor) {
    BackgroundSettings.sharedService.backgroundColor = color;
}

func setImageTintColor(_ imageView: UIImageView?, tintColor color: UIColor?) -> UIImageView? {
    imageView?.image = imageView?.image?.withRenderingMode(.alwaysTemplate)
    if let aColor = color {
        imageView?.tintColor = aColor
    }
    return imageView
}

func setButtonTintColor(_ button: UIButton?, imageName: String?, state: UIControl.State, tintColor color: UIColor?) -> UIButton? {
    button?.setImage((UIImage(named: imageName ?? ""))?.withRenderingMode(.alwaysTemplate), for: state)
    button?.tintColor = color
    return button
}

func setFontFamily(_ fontFamily: String?, view: UIView?, size: Float, textColor: UIColor) {//, andSubViews isSubViews: Bool
    if (view is UILabel) {
        let lbl = view as? UILabel
        lbl?.font = UIFont(name: fontFamily ?? "", size: CGFloat(size))
        lbl?.textColor = textColor
    }
    else if (view is UIButton) {
        let btn = view as? UIButton
        btn?.titleLabel?.font =  UIFont(name: fontFamily ?? "", size: CGFloat(size))
        btn?.setTitleColor(textColor, for: .normal)
    }
    else if (view is UITextField) {
        let txt = view as? UITextField
        txt?.font = UIFont(name: fontFamily ?? "", size: CGFloat(size))
        txt?.textColor = textColor
    }
}

func fontSize(size: Float) -> Float {
    if IPAD {
        if size == QIBUS_SIZE_XXXLARGE {
            return 40
        }
        else if size == QIBUS_SIZE_XXLARGE {
            return 34
        }
        else if size == QIBUS_SIZE_XLARGE {
            return 24
        }
        else if size == QIBUS_SIZE_LARGE {
            return 24
        }
        else if size == QIBUS_SIZE_NORMAL {
            return 22
        }
        else if size == QIBUS_SIZE_MEDIUM {
            return 20
        }
        else if size == QIBUS_SIZE_MSMALL {
            return 18
        }
        else if size == QIBUS_SIZE_SMALL {
            return 16
        }
        else if size == QIBUS_SIZE_TINY {
            return 14
        }
        else {
            return 14
        }
    }
    else {
        if size == QIBUS_SIZE_XXXLARGE {
            return 35
        }
        else if size == QIBUS_SIZE_XXLARGE {
            return 30
        }
        else if size == QIBUS_SIZE_XLARGE {
            return 24
        }
        else if size == QIBUS_SIZE_LARGE {
            return 20
        }
        else if size == QIBUS_SIZE_NORMAL {
            return 18
        }
        else if size == QIBUS_SIZE_MEDIUM {
            return 16
        }
        else if size == QIBUS_SIZE_MSMALL {
            return 14
        }
        else if size == QIBUS_SIZE_SMALL {
            return 12
        }
        else if size == QIBUS_SIZE_TINY {
            return 10
        }
        else {
            return 10
        }
    }
}

func CornerRadiousWithShadow(view: UIView?, cornerRadus: CGFloat) {
    view?.layer.cornerRadius = cornerRadus
    view?.layer.shadowColor = UIColor.black.cgColor
    view?.layer.shadowOpacity = 0.3
    view?.layer.shadowRadius = 1.0
    view?.layer.shadowOffset = CGSize.zero
}

func CornerRadious(view: UIView?, cornerRadus: CGFloat) {
    view?.layer.cornerRadius = cornerRadus
    view?.layer.masksToBounds = true
}

func CornerRadiousWithBackground(view: UIView?, color: UIColor, cornerRadus: CGFloat) {
    view?.backgroundColor = color
    view?.layer.cornerRadius = cornerRadus
    view?.layer.masksToBounds = true
}

func CornerRadiousWithBorder(view: UIView?, color: UIColor, cornerRadus: CGFloat, borderWidth: CGFloat) {
    view?.layer.borderWidth = borderWidth
    view?.layer.borderColor = color.cgColor
    view?.layer.cornerRadius = cornerRadus
    view?.layer.masksToBounds = true
}

func Shadow(view: UIView?) {
    view?.layer.shadowColor = UIColor.black.cgColor
    view?.layer.shadowOpacity = 0.3
    view?.layer.shadowRadius = 1.0
    view?.layer.shadowOffset = CGSize.zero
    view?.layer.masksToBounds = false
}

func RemoveCornerRadiousWithShadow(view: UIView?) {
    view?.layer.cornerRadius = 0
    view?.layer.shadowColor = UIColor.clear.cgColor
    view?.layer.shadowOpacity = 0.0
    view?.layer.shadowRadius = 0.0
    view?.layer.shadowOffset = CGSize.zero
}

func Share(view: UIViewController) {
    // set up activity view controller
    let share = [""]
    let activityViewController = UIActivityViewController(activityItems: share, applicationActivities: nil)
    activityViewController.popoverPresentationController?.sourceView = view.view // so that iPads won't crash
    
    // present the view controller
    view.present(activityViewController, animated: true, completion: nil)
}

func SegmentApprience(segment: UISegmentedControl) {
    let segSelectedAttributes: NSDictionary = [
        NSAttributedString.Key.foregroundColor: UIColor(hexString: QIBUS_BTN_TEXT_COLOR),
        NSAttributedString.Key.font: UIFont(name: QIBUS_PRIMARY_FONT_SEMIBOLD, size: CGFloat(fontSize(size: QIBUS_SIZE_MSMALL)))!
    ]
    segment.setTitleTextAttributes(segSelectedAttributes as? [NSAttributedString.Key : Any], for: .selected)
    
    let segNormalAttributes: NSDictionary = [
        NSAttributedString.Key.foregroundColor: UIColor(hexString: QIBUS_PRIMARY_TEXT_COLOR),
        NSAttributedString.Key.font: UIFont(name: QIBUS_PRIMARY_FONT_SEMIBOLD, size: CGFloat(fontSize(size: QIBUS_SIZE_MSMALL)))!
    ]
    segment.setTitleTextAttributes(segNormalAttributes as? [NSAttributedString.Key : Any], for: .normal)
}

extension UIView {
    func roundCorners(_ corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}

