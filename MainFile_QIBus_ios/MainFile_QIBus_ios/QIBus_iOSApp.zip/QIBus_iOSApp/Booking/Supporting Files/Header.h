//
//  Header.h
//  SofUi
//
//  Copyright © 2019. All rights reserved.
//

#ifndef Header_h
#define Header_h

#import "SWNinePatchImageFactory.h"

#endif /* Header_h */
