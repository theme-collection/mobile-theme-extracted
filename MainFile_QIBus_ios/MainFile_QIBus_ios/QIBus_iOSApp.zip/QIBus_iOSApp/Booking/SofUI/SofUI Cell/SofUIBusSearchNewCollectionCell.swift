//
//  SofUIBusSearchNewCollectionCell.swift

import UIKit

class SofUIBusSearchNewCollectionCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwTravelsName: UIView!
    @IBOutlet weak var vwCellBackground: UIView!
    
    @IBOutlet weak var lblTravelsName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblFromTime: UILabel!
    @IBOutlet weak var lblFromAM: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblHolds: UILabel!
    @IBOutlet weak var lblToTime: UILabel!
    @IBOutlet weak var lblToAm: UILabel!
    @IBOutlet weak var lblRatting: UILabel!
    @IBOutlet weak var lblBusType: UILabel!
    
    @IBOutlet weak var imgBus1: UIImageView!
    @IBOutlet weak var imgBus2: UIImageView!
    
    @IBOutlet weak var btnTime: UIButton!
    @IBOutlet weak var btnStar: UIButton!
    @IBOutlet weak var img9patch: UIImageView!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
//        CornerRadiousWithBackground(view: vwTravelsName, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
//        CornerRadious(view: vwCellBackground, cornerRadus: 5.0)
//        Shadow(view: self)
//        CornerRadiousWithBackground(view: btnTime, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: 5.0)
        
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

        img9patch?.image = resizableImage
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTravelsName, size: fontSize(size: SIZE_MEDIUM), textColor: .white)
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblAmount, size: fontSize(size: SIZE_LARGE), textColor: UIColor(hexString: PRIMARY_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblFromTime, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblFromAM, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblToTime, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblToAm, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblDuration, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblHolds, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblRatting, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblBusType, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR))
        
        imgBus1 = setImageTintColor(imgBus1, tintColor: UIColor(hexString: PRIMARY_COLOR))
        imgBus2 = setImageTintColor(imgBus2, tintColor: UIColor(hexString: PRIMARY_COLOR))
        
        self.vwTravelsName.layer.cornerRadius = 5.0
        self.btnTime.layer.cornerRadius = 5.0
    }

}
