//
//  SofUIPickUpTableCell.swift

import UIKit

class SofUIPickUpTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var vwPickup: UIView!
    
    @IBOutlet weak var imgPickup: UIImageView!
    @IBOutlet weak var lblPickup: UILabel!
    @IBOutlet weak var lblLandmark: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPickup, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTime, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblLandmark, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        
//        CornerRadiousWithShadow(view: vwPickup, cornerRadus: 5.0)
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

        imgPickup?.image = resizableImage
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
