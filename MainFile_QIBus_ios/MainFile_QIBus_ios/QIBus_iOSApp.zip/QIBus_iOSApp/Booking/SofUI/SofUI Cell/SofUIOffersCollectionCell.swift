//
//  SofUIOffersCollectionCell.swift

import UIKit

class SofUIOffersCollectionCell: UICollectionViewCell {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgOffer: UIImageView!
    
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblValidity: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var vwOffer: UIView!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        CornerRadious(view: vwBackground, cornerRadus: 5.0)
       // Shadow(view: self)
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblMessage, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblValidity, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblCode, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        
        if #available(iOS 11.0, *) {
            self.vwOffer.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        } else {
            // Fallback on earlier versions
        }
        self.vwOffer.layer.cornerRadius = 10.0
        
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

        imgOffer?.image = resizableImage
    }

}
