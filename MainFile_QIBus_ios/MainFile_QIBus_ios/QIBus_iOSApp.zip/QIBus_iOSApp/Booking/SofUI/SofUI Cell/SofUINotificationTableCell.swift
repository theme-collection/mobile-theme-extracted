//
//  SofUINotificationTableCell.swift

import UIKit

class SofUINotificationTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgNotification: UIImageView!
    @IBOutlet weak var vwDate: UIView!
    @IBOutlet weak var vwNotification: UIView!
    
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblMonth: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblConfirmed: UILabel!
    @IBOutlet weak var lblBusName: UILabel!
    
    @IBOutlet weak var imgConfirmed: UIImageView!
    @IBOutlet weak var imgBus: UIImageView!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
//        CornerRadiousWithBorder(view: vwDate, color: BackgroundSettings.sharedService.backgroundColor, cornerRadus: vwDate.frame.height / 2, borderWidth: 1.0)
//        CornerRadiousWithShadow(view: vwNotification, cornerRadus: 5.0)
//        CornerRadiousWithBorder(view: imgConfirmed, color: UIColor(hexString: GREEN), cornerRadus: imgConfirmed.frame.height / 2, borderWidth: 1.0)
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblDate, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblMonth, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblAddress, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblBusName, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblConfirmed, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: GREEN))
        
        imgConfirmed = setImageTintColor(imgConfirmed, tintColor: UIColor(hexString: GREEN))
        imgBus = setImageTintColor(imgBus, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        
        let resizableLogin = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")
        imgNotification?.image = resizableLogin
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
