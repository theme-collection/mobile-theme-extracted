//
//  SofUIPackageCollectionViewCell.swift

import UIKit

class SofUIPackageCollectionViewCell: UICollectionViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgPkg: UIImageView!
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnBus: UIButton!
    @IBOutlet weak var btnRestorent: UIButton!
    @IBOutlet weak var btnWiifi: UIButton!
    
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var vwLikeBackgroung: UIView!
    
    @IBOutlet weak var imgPackage: UIImageView!
    
    @IBOutlet weak var lblPackageName: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblPriceWithDiscount: UILabel!
    @IBOutlet weak var lblActualPrice: UILabel!
    @IBOutlet weak var lblBooking: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

               imgPkg?.image = resizableImage
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPackageName, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblDuration, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblPriceWithDiscount, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblActualPrice, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblBooking, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        
        btnHome = setButtonTintColor(btnHome, imageName: "icoHome1", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        btnBus = setButtonTintColor(btnBus, imageName: "icoBus", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        btnRestorent = setButtonTintColor(btnRestorent, imageName: "icoRestorent", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        btnWiifi = setButtonTintColor(btnWiifi, imageName: "icoWifi", state: .normal, tintColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        
        btnLike = setButtonTintColor(btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLOR))
        
        CornerRadious(view: btnLike, cornerRadus: btnLike.frame.height / 2)
        CornerRadious(view: vwLikeBackgroung, cornerRadus: vwLikeBackgroung.frame.height / 2)
        CornerRadious(view: imgPackage, cornerRadus: 5.0)
//        Shadow(view: self)
        CornerRadious(view: vwBackground, cornerRadus: 5.0)
        
        let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: lblActualPrice.text ?? "")
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSMakeRange(0, attributeString.length))
        lblActualPrice.attributedText = attributeString
    }
}
