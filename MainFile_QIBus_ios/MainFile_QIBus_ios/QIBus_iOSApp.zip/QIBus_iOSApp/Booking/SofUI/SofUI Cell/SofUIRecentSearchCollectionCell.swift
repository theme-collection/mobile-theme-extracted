//
//  SofUIRecentSearchCollectionCell.swift

import UIKit

class SofUIRecentSearchCollectionCell: UICollectionViewCell {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgRecent: UIImageView!
    @IBOutlet weak var vwBackground: UIView!
    
    @IBOutlet weak var btnBus: UIButton!
    
    @IBOutlet weak var lblCty: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var btnBook: UIButton!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()

        CornerRadious(view: vwBackground, cornerRadus: 5.0)
       // Shadow(view: self)
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblCty, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblDate, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnBook, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR))
        
        btnBus = setButtonTintColor(btnBus, imageName: "icoBus", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLOR))
        btnBook.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

        imgRecent?.image = resizableImage
        
        if #available(iOS 11.0, *) {
            self.btnBook.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        } else {
            // Fallback on earlier versions
        }
        self.btnBook.layer.cornerRadius = 10.0
    }

}
