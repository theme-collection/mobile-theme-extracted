//
//  SofUIMoreTableCell.swift

import UIKit

class SofUIMoreTableCell: UITableViewCell {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var imgMore: UIImageView!
    @IBOutlet weak var vwMoreListing: UIView!
    
    @IBOutlet weak var imgMore1: UIImageView!
    
    @IBOutlet weak var lblMore: UILabel!
    
    //MARK: -
    //MARK: - Set up Cell
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblMore, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
                
//        CornerRadiousWithShadow(view: vwMoreListing, cornerRadus: 5.0)
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

        imgMore1?.image = resizableImage
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
