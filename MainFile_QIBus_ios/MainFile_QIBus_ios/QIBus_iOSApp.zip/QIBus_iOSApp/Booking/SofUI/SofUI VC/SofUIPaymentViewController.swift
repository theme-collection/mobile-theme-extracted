//
//  SofUIPaymentViewController.swift

import UIKit

class SofUIPaymentViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintTblPaymentHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    @IBOutlet weak var constraintCvCardsHeight: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwCard: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblCardType: UILabel!
    @IBOutlet weak var lblCardNo: UILabel!
    @IBOutlet weak var lblValid: UILabel!
    @IBOutlet weak var lblValidDate: UILabel!
    @IBOutlet weak var lblCardHolderName: UILabel!
    
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var tblPayment: UITableView!
    
    @IBOutlet weak var cvCards: UICollectionView!
    
    @IBOutlet weak var imgCard: UIImageView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrPaymentImage = ["icoNetBanking", "icoCard", "icoCard", "icoWallet1"]
    let arrPayment = ["Net Banking", "Credit Card", "Debit Card", "Mobile Wallet"]
    
    let arrCardsImage = ["icoCard1"]
    let arrCardsType = ["PayPal"]
    
    var strFromCity = String()
    var strToCity = String()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
        setFontFamily(PRIMARY_FONT_BOLD, view: lblCardType, size: fontSize(size: SIZE_MEDIUM), textColor: .white)
        setFontFamily(PRIMARY_FONT_BOLD, view: lblCardNo, size: fontSize(size: SIZE_MEDIUM), textColor: .white)
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblValidDate, size: fontSize(size: SIZE_MSMALL), textColor: .white)
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblCardHolderName, size: fontSize(size: SIZE_MSMALL), textColor: .white)
        setFontFamily(PRIMARY_FONT, view: lblValid, size: fontSize(size: SIZE_MSMALL), textColor: .white)
        
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        CornerRadiousWithShadow(view: vwCard, cornerRadus: 5.0)
        
        tblPayment.tableFooterView = UIView(frame: .zero)
    }
    
    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrCardsType.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cvCards.register(UINib(nibName: "SofUICardListCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        
        let cell = cvCards.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SofUICardListCollectionCell
        
        cell.lblCardType.text = arrCardsType[indexPath.item]
//        cell.imgCard.image = UIImage(named: arrCardsImage[indexPath.item])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = SofUICardViewController(nibName: "SofUICardViewController", bundle: nil)
        vc.isFromAdd = false
        vc.isFromMore = false
        vc.strFromCity = strFromCity
        vc.strToCity = strToCity
        present(vc, animated: true, completion: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        if IPAD {
//            constraintCvCardsHeight.constant = CGFloat((arrCardsType.count) * (200 + 16))
//            return CGSize(width: (UIScreen.main.bounds.size.width)-32, height: 200)
//        }
//        else {
//            constraintCvCardsHeight.constant = CGFloat(arrCardsType.count * 180)
//            return CGSize(width: UIScreen.main.bounds.size.width-16, height: 180)
//        }
        return CGSize(width: UIScreen.main.bounds.size.width, height: 230)
    }
    
    //MARK: -
    //MARK: - UITableView DataSource & Delegate
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPayment.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        if IPAD {
//            constraintTblPaymentHeight.constant = CGFloat(arrPayment.count * 80)
//            return 80
//        }
//        else {
//            constraintTblPaymentHeight.constant = CGFloat(arrPayment.count * 60)
//            return 60
//        }
         constraintTblPaymentHeight.constant = CGFloat(arrPayment.count * 100)
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tblPayment.register(UINib(nibName: "SofUIMoreTableCell", bundle: nil), forCellReuseIdentifier: "Cell")
        let cell = tblPayment.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! SofUIMoreTableCell
        
        cell.imgMore.image = UIImage(named: arrPaymentImage[indexPath.row])
        cell.lblMore.text = arrPayment[indexPath.row]
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 1 {
            let vc = SofUICardViewController(nibName: "SofUICardViewController", bundle: nil)
            vc.isFromAdd = true
            vc.isFromMore = false
            vc.strFromCity = strFromCity
            vc.strToCity = strToCity
            present(vc, animated: true, completion: nil)
        }
        else if indexPath.row == 2 {
            let vc = SofUICardViewController(nibName: "SofUICardViewController", bundle: nil)
            vc.isFromAdd = true
            vc.isFromMore = false
            vc.strFromCity = strFromCity
            vc.strToCity = strToCity
            present(vc, animated: true, completion: nil)
        }
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnCard_Clicked(_ sender: Any) {
        let vc = SofUICardViewController(nibName: "SofUICardViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnAddCard_Clicked(_ sender: Any) {
        let vc = SofUICardViewController(nibName: "SofUICardViewController", bundle: nil)
        vc.isFromAdd = true
        vc.isFromMore = false
        vc.strFromCity = strFromCity
        vc.strToCity = strFromCity
        present(vc, animated: true, completion: nil)
    }
}
