//
//  SofUITabBarViewController.swift

import UIKit
import AVFoundation

class SofUITabBarViewController: UIViewController {
    
    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var imgTabBar: UIImageView!
    @IBOutlet weak var vwTemp: UIView!
    @IBOutlet weak var vwHeader: UIView!
    
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnPackage: UIButton!
    @IBOutlet weak var btnBooking: UIButton!
    @IBOutlet weak var btnMore: UIButton!
    @IBOutlet weak var btnNotification: UIButton!
    
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var lblBadge: UILabel!
    
    //MARK: -
    //MARK: - Variables
    
    var home = SofUIHomeViewController()
    var package = SofUIPackagesViewController()
    var myBooking = SofUIMyBookingViewController()
    var more = SofUIMoreViewController()
        
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        CornerRadious(view: vwTemp, cornerRadus: 10.0)
        CornerRadiousWithBorder(view: lblBadge, color: UIColor(hexString: PRIMARY_COLOR), cornerRadus: lblBadge.frame.height / 2, borderWidth: 1.0)
        let resizableLogin = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")
        imgTabBar.image = resizableLogin
        package.view.removeFromSuperview()
        myBooking.view.removeFromSuperview()
        more.view.removeFromSuperview()
        addChild(home)
        vwTemp.addSubview(home.view)
        home.didMove(toParent: self)
        home.view.frame = vwTemp.bounds
        home.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        btnHome.isSelected = true
        btnHome.setBackgroundImage(UIImage(named: "iqbus_softui_circle"), for: UIControl.State.normal)
        
        btnHome.setImage(UIImage(named: "icoHome"), for: .normal)
        btnHome.setImage(UIImage(named: "icoHomeSelected"), for: .selected)
        btnPackage.setImage(UIImage(named: "icoPackage"), for: .normal)
        btnPackage.setImage(UIImage(named: "icoPackageSelected"), for: .selected)
        btnBooking.setImage(UIImage(named: "icoBooking"), for: .normal)
        btnBooking.setImage(UIImage(named: "icoBookingSelected"), for: .selected)
        btnMore.setImage(UIImage(named: "icoMore"), for: .normal)
        btnMore.setImage(UIImage(named: "icoMoreSelected"), for: .selected)
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeader, size: fontSize(size: SIZE_LARGE), textColor: .white)
        setFontFamily(PRIMARY_FONT_BOLD, view: lblBadge, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        
//        btnHome.backgroundColor = UIColor(hexString: PRIMARY_COLOR, alpha: 0.2)
        btnHome.layer.cornerRadius = btnHome.frame.height / 2
        btnHome.layer.masksToBounds = true
        btnPackage.layer.cornerRadius = btnHome.frame.height / 2
        btnPackage.layer.masksToBounds = true
        btnBooking.layer.cornerRadius = btnHome.frame.height / 2
        btnBooking.layer.masksToBounds = true
        btnMore.layer.cornerRadius = btnHome.frame.height / 2
        btnMore.layer.masksToBounds = true
        
        btnNotification.setImage(UIImage.gif(name: "icoGifBell"), for: .normal)
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnHome_Clicked(_ sender: Any) {
        lblHeader.text = "Home"
        
//        btnHome.backgroundColor = UIColor(hexString: PRIMARY_COLOR, alpha: 0.2)
//        btnPackage.backgroundColor = .white
//        btnBooking.backgroundColor = .white
//        btnMore.backgroundColor = .white
        btnHome.setBackgroundImage(UIImage(named: "iqbus_softui_circle"), for: UIControl.State.normal)
        btnPackage.setBackgroundImage(nil, for: UIControl.State.normal)
        btnBooking.setBackgroundImage(nil, for: UIControl.State.normal)
        btnMore.setBackgroundImage(nil, for: UIControl.State.normal)
        
        btnHome.isSelected = true
        btnPackage.isSelected = false
        btnBooking.isSelected = false
        btnMore.isSelected = false
        
        package.view.removeFromSuperview()
        myBooking.view.removeFromSuperview()
        more.view.removeFromSuperview()
        addChild(home)
        vwTemp.addSubview(home.view)
        home.didMove(toParent: self)
        home.view.frame = vwTemp.bounds
        home.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.view.setNeedsLayout()
    }
    
    @IBAction func btnPackage_Clicked(_ sender: Any) {
        lblHeader.text = "Packages"
        
//        btnHome.backgroundColor = .white
//        btnPackage.backgroundColor = UIColor(hexString: PRIMARY_COLOR, alpha: 0.2)
//        btnBooking.backgroundColor = .white
//        btnMore.backgroundColor = .white
        
        btnPackage.setBackgroundImage(UIImage(named: "iqbus_softui_circle"), for: UIControl.State.normal)
        btnHome.setBackgroundImage(nil, for: UIControl.State.normal)
        btnBooking.setBackgroundImage(nil, for: UIControl.State.normal)
        btnMore.setBackgroundImage(nil, for: UIControl.State.normal)
        
        btnHome.isSelected = false
        btnPackage.isSelected = true
        btnBooking.isSelected = false
        btnMore.isSelected = false
        
        home.btnDone.isHidden = true
        home.datePicker.isHidden = true
        home.vwBackground.isHidden = true
        home.view.removeFromSuperview()
        myBooking.view.removeFromSuperview()
        more.view.removeFromSuperview()
        addChild(package)
        vwTemp.addSubview(package.view)
        package.didMove(toParent: self)
        package.view.frame = vwTemp.bounds
        package.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.view.setNeedsLayout()
    }
    
    @IBAction func btnBooking_Clicked(_ sender: Any) {
        lblHeader.text = "My Booking"
        
//        btnHome.backgroundColor = .white
//        btnPackage.backgroundColor = .white
//        btnBooking.backgroundColor = UIColor(hexString: PRIMARY_COLOR, alpha: 0.2)
//        btnMore.backgroundColor = .white
        
        btnBooking.setBackgroundImage(UIImage(named: "iqbus_softui_circle"), for: UIControl.State.normal)
        btnHome.setBackgroundImage(nil, for: UIControl.State.normal)
        btnPackage.setBackgroundImage(nil, for: UIControl.State.normal)
        btnMore.setBackgroundImage(nil, for: UIControl.State.normal)
        
        btnHome.isSelected = false
        btnPackage.isSelected = false
        btnBooking.isSelected = true
        btnMore.isSelected = false
        
        home.btnDone.isHidden = true
        home.datePicker.isHidden = true
        home.vwBackground.isHidden = true
        package.view.removeFromSuperview()
        home.view.removeFromSuperview()
        more.view.removeFromSuperview()
        addChild(myBooking)
        vwTemp.addSubview(myBooking.view)
        myBooking.didMove(toParent: self)
        myBooking.view.frame = vwTemp.bounds
        myBooking.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.view.setNeedsLayout()
    }
    
    @IBAction func btnMore_Clicked(_ sender: Any) {
        lblHeader.text = "More"

//        btnHome.backgroundColor = .white
//        btnPackage.backgroundColor = .white
//        btnBooking.backgroundColor = .white
//        btnMore.backgroundColor = UIColor(hexString: PRIMARY_COLOR, alpha: 0.2)
        
        btnMore.setBackgroundImage(UIImage(named: "iqbus_softui_circle"), for: UIControl.State.normal)
        btnHome.setBackgroundImage(nil, for: UIControl.State.normal)
        btnPackage.setBackgroundImage(nil, for: UIControl.State.normal)
        btnBooking.setBackgroundImage(nil, for: UIControl.State.normal)
        
        btnHome.isSelected = false
        btnPackage.isSelected = false
        btnBooking.isSelected = false
        btnMore.isSelected = true
        
        home.btnDone.isHidden = true
        home.datePicker.isHidden = true
        home.vwBackground.isHidden = true
        package.view.removeFromSuperview()
        myBooking.view.removeFromSuperview()
        home.view.removeFromSuperview()
        addChild(more)
        vwTemp.addSubview(more.view)
        more.didMove(toParent: self)
        more.view.frame = vwTemp.bounds
        more.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.view.setNeedsLayout()
    }
    
    @IBAction func btnNotification_Clicked(_ sender: UIButton) {
        let vc = SofUINotificationViewController(nibName: "SofUINotificationViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
}
