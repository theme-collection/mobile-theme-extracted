//
//  SofUIProfileSettingsViewController.swift

import UIKit

class SofUIProfileSettingsViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    //MARK: -
    //MARK: - Otulets
    
    @IBOutlet weak var btnProfile: UIButton!
    @IBOutlet weak var imgContact: UIImageView!
    @IBOutlet weak var imgName: UIImageView!
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwName: UIView!
    @IBOutlet weak var vwContact: UIView!
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnNotification: UIButton!
    
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblNameHeading: UILabel!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblGenderValue: UILabel!
    @IBOutlet weak var lblContactHeading: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblContactNo: UILabel!
    @IBOutlet weak var lblBadge: UILabel!

    @IBOutlet weak var genderPicker: UIPickerView!
    
    @IBOutlet weak var imgProfile: UIImageView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrGender = ["Male", "Female", "Other"]
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
//        self.btnSave.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        self.btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        genderPicker.backgroundColor = .white
        btnDone.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
//        CornerRadious(view: vwMain, cornerRadus: 10.0)
//        CornerRadiousWithShadow(view: vwName, cornerRadus: 5.0)
//        CornerRadiousWithShadow(view: vwContact, cornerRadus: 5.0)
//        CornerRadious(view: btnSave, cornerRadus: 5.0)
//        CornerRadiousWithShadow(view: btnAdd, cornerRadus: btnAdd.frame.height / 2)
        CornerRadious(view: imgProfile, cornerRadus: imgProfile.frame.height / 2)
        CornerRadiousWithBorder(view: lblBadge, color: UIColor(hexString: PRIMARY_COLOR), cornerRadus: lblBadge.frame.height / 2, borderWidth: 1.0)
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblBadge, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblNameHeading, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblFirstName, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblLastName, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblGender, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblGenderValue, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblContactHeading, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblEmail, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblContactNo, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
//        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnSave, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: btnDone, size: fontSize(size: SIZE_MEDIUM), textColor: UIColor(hexString: BTN_TEXT_COLOR))
        
        btnNotification.setImage(UIImage.gif(name: "icoGifBell"), for: .normal)
        
        let resizableImage = SWNinePatchImageFactory.createResizableNinePatchImageNamed("12.9")

        imgName?.image = resizableImage
        imgContact?.image = resizableImage
        
        let resizableLogin1 = SWNinePatchImageFactory.createResizableNinePatchImageNamed("ios.9")
        btnSave.setBackgroundImage(resizableLogin1, for: UIControl.State.normal)
        btnProfile.layer.cornerRadius = btnProfile.frame.size.height / 2
    }
    
    //MARK: -
    //MARK: - UITextfield Delegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        genderPicker.isHidden = true
        btnDone.isHidden = true
    }
    
    //MARK: -
    //MARK: - Picker View Delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrGender.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrGender[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblGenderValue.text = arrGender[row]
    }

    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnSave_Clicked(_ sender: Any) {
        view.makeToast("Saved")
    }
    
    @IBAction func btnAdd_Clicked(_ sender: Any) {
        
    }
    
    @IBAction func btnGender_Clicked(_ sender: Any) {
        view.endEditing(true)
        genderPicker.isHidden = false
        btnDone.isHidden = false
    }
    
    @IBAction func btnDone_Clicked(_ sender: Any) {
        genderPicker.isHidden = true
        btnDone.isHidden = true
    }
    
    @IBAction func btnNotification_Clicked(_ sender: UIButton) {
        let vc = SofUINotificationViewController(nibName: "SofUINotificationViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
}
