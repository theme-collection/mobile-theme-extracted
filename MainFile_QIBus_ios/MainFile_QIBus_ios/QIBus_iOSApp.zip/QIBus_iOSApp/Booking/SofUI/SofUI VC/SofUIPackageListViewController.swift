//
//  SofUIPackageListViewController.swift

import UIKit

class SofUIPackageListViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    @IBOutlet weak var lblHeading: UILabel!
    
    @IBOutlet weak var cvPackage: UICollectionView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrPackage = ["Kerala", "Goa", "Andamans", "Amritsar", "Udaipur"]
    let arrLike = NSMutableArray()
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - SetUpView
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
    }

    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cvPackage.register(UINib(nibName: "SofUIPackageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        let cell = cvPackage.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SofUIPackageCollectionViewCell
        
        cell.lblPackageName.text = arrPackage[indexPath.item]
        cell.imgPackage.image = UIImage(named: arrPackage[indexPath.item])
        
        cell.btnLike.tag = indexPath.item
        cell.btnLike.addTarget(self, action: #selector(onClickLikePackage(_:)), for: UIControl.Event.touchUpInside)
        
        if arrLike.contains(indexPath.item) {
            cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeartFill", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLOR))
        }
        else {
            cell.btnLike = setButtonTintColor(cell.btnLike, imageName: "icoHeart", state: .normal, tintColor: UIColor(hexString: PRIMARY_COLOR))
        }
            
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 300)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = SofUIBusSearchViewController(nibName: "SofUIBusSearchViewController", bundle: nil)
        self.present(vc, animated: true, completion: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        willDisplay cell: UICollectionViewCell,
                        forItemAt indexPath: IndexPath) {
        cell.contentView.alpha = 0.3
        
        cell.layer.transform = CATransform3DMakeScale(0.5, 0.5, 0.5)
        
        // Simple Animation
        UIView.animate(withDuration: 0.5) {
            cell.contentView.alpha = 1
            cell.layer.transform = CATransform3DScale(CATransform3DIdentity, 1, 1, 1)
        }
    }
    
    //MARK: -
    //MARK: - Cell UIButton Action Method
    
    @objc func onClickLikePackage(_ sender: UIButton?) {
        if sender!.isSelected {
            sender?.isSelected = false
            arrLike.remove(sender?.tag as Any)
        }
        else {
            sender?.isSelected = true
            arrLike.add(sender?.tag as Any)
        }
        let indexPaths = IndexPath(item: sender!.tag, section: 0)
        cvPackage.reloadItems(at: [indexPaths])
    }
    
    //MARK: -
    //MARK: - UIButton Action Method

    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
