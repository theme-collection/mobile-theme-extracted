//
//  SofUICardListViewController.swift

import UIKit

class SofUICardListViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var vwHeader: UIView!
    
    @IBOutlet weak var lblHeading: UILabel!
    
    @IBOutlet weak var cvCards: UICollectionView!
    
    //MARK: -
    //MARK: - Variables
    
    let arrCardsImage = ["icoCard1", "icoCard3"]
    let arrCardsType = ["Paypal", "VISA"]
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }

    //MARK: -
    //MARK: - SetUpView

    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
        
        CornerRadious(view: cvCards, cornerRadus: 10.0)
    }
    
    //MARK: -
    //MARK: -UICollectionView Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrCardsType.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cvCards.register(UINib(nibName: "SofUICardListCollectionCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        
        let cell = cvCards.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SofUICardListCollectionCell
        
        cell.lblCardType.text = arrCardsType[indexPath.item]
//        cell.imgCard.image = UIImage(named: arrCardsImage[indexPath.item])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.size.width, height: 230)
    }
    
    //MARK: -
    //MARK: - UIButton Action Method

    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnAddCard_Clicked(_ sender: Any) {
        let vc = SofUICardViewController(nibName: "SofUICardViewController", bundle: nil)
        vc.isFromAdd = true
        vc.isFromMore = true
        present(vc, animated: true, completion: nil)
    }
}
