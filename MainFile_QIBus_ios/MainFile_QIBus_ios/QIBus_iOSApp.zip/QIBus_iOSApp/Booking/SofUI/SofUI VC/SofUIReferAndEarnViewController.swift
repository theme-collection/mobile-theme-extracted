//
//  SofUIReferAndEarnViewController.swift
//  Booking
//
//  Created by Goldenmace-E41 on 25/06/19.
//  Copyright © 2019 GMITS. All rights reserved.
//

import UIKit

class SofUIReferAndEarnViewController: UIViewController {

    //MARK: -
    //MARK: - Outlets
    
    @IBOutlet weak var constraintHeaderTop: NSLayoutConstraint!
    
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblTotalEarning: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblYourCode: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblYourLink: UILabel!
    @IBOutlet weak var lblLink: UILabel!
    @IBOutlet weak var lblBadge: UILabel!
    
    @IBOutlet weak var btnNotification: UIButton!
    
    @IBOutlet weak var vwHeader: UIView!
    @IBOutlet weak var vwMain: UIView!
    
    //MARK: -
    //MARK: - UIView life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SetUpView()
    }
    
    //MARK: -
    //MARK: - Set Up View
    
    func SetUpView() {
        if #available(iOS 11.0, *) {
            
        } else {
            constraintHeaderTop.constant = UIApplication.shared.statusBarFrame.size.height
        }
        
        self.view.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        vwHeader.backgroundColor = BackgroundSettings.sharedService.backgroundColor
        
        CornerRadious(view: vwMain, cornerRadus: 10.0)
        CornerRadiousWithBorder(view: lblBadge, color: UIColor(hexString: PRIMARY_COLOR), cornerRadus: lblBadge.frame.height / 2, borderWidth: 1.0)
        
        setFontFamily(PRIMARY_FONT_BOLD, view: lblBadge, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_BOLD, view: lblHeading, size: fontSize(size: SIZE_LARGE), textColor: .white)
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotalEarning, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblTotal, size: fontSize(size: SIZE_XLARGE), textColor: UIColor(hexString: PRIMARY_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblYourCode, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblCode, size: fontSize(size: SIZE_MSMALL), textColor: .blue)
        setFontFamily(PRIMARY_FONT, view: lblMessage, size: fontSize(size: SIZE_SMALL), textColor: UIColor(hexString: SECONDARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT, view: lblYourLink, size: fontSize(size: SIZE_MSMALL), textColor: UIColor(hexString: PRIMARY_TEXT_COLOR))
        setFontFamily(PRIMARY_FONT_SEMIBOLD, view: lblLink, size: fontSize(size: SIZE_MSMALL), textColor: .blue)
        
        btnNotification.setImage(UIImage.gif(name: "icoGifBell"), for: .normal)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tapFunction))
        lblCode.isUserInteractionEnabled = true
        lblCode.addGestureRecognizer(tap)
    }
    
    //MARK: -
    //MARK: - UITapGestureRecognizer Method
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {
        self.view.makeToast("Copied")
    }
    
    //MARK: -
    //MARK: - UIButton Action Method
    
    @IBAction func btnBack_Clicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnNotification_Clicked(_ sender: UIButton) {
        let vc = SofUINotificationViewController(nibName: "SofUINotificationViewController", bundle: nil)
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func btnFacebook_Clicked(_ sender: Any) {
        Share(view: self)
    }
    
    @IBAction func btnWhatsapp_Clicked(_ sender: Any) {
        Share(view: self)
    }
    
    @IBAction func btnGoogle_Clicked(_ sender: Any) {
        Share(view: self)
    }
    
    @IBAction func btnTwiter_Clicked(_ sender: Any) {
        Share(view: self)
    }   
}
